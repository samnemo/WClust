// KMDialog.cpp : implementation file
//

#include "stdafx.h"
#include "WClust.h"
#include "KMDialog.h"
#include ".\kmdialog.h"


// KMDialog dialog

IMPLEMENT_DYNAMIC(KMDialog, CDialog)
KMDialog::KMDialog(CWnd* pParent /*=NULL*/)
	: CDialog(KMDialog::IDD, pParent),
	  m_iMinClusts(4),
	  m_iMaxClusts(20),
	  m_iIters(100),
	  m_iDBIters(1),
	  m_iNormalizeData(0),
	  m_iUseMedians(0)
{
}

KMDialog::~KMDialog()
{
}

void KMDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(KMDialog, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()


// KMDialog message handlers

void KMDialog::OnBnClickedOk()
{
	CEdit* edit = (CEdit*)GetDlgItem(IDC_EDIT_KM);
	edit->SetFocus();
	CString strEdit;
	edit->GetWindowText(strEdit);

	sscanf(strEdit.GetString(),"%d%d%d%d%d%d",&m_iMinClusts,&m_iMaxClusts,&m_iIters,&m_iDBIters,&m_iNormalizeData,&m_iUseMedians);

	OnOK();
}
