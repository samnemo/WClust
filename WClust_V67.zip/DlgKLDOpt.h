#pragma once
#include "afxcmn.h"


// DlgKLDOpt dialog

class DlgKLDOpt : public CDialog
{
	DECLARE_DYNAMIC(DlgKLDOpt)

public:
	DlgKLDOpt(CWnd* pParent = NULL);   // standard constructor
	virtual ~DlgKLDOpt();

// Dialog Data
	enum { IDD = IDD_DIALOG_KLD_DLG_OPT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CSpinButtonCtrl m_spinBtn;
	int m_iNNToFind;
	afx_msg void OnDeltaposSpinnnkld(NMHDR *pNMHDR, LRESULT *pResult);
	BOOL m_bFast;
};
