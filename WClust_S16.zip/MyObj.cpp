// MyObj.cpp: implementation of the CMyObject class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "wclust.h"
#include "MyObj.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMyObject::CMyObject()
{

}

CMyObject::~CMyObject()
{

}



//////////////////////////////////////////////////////////////////////
// CPaletteStack
CPaletteStack::CPaletteStack()
{
	NumColors=0;

	AddSColor(RGB(0x90,0x90,0x90));//0

	AddSColor(RGB(0xFF,0x00,0x00));
	AddSColor(RGB(0x00,0x00,0xFF));//2
	AddSColor(RGB(0x00,0xFF,0x00));

	AddSColor(RGB(0xF0,0x00,0xF0));//4
	AddSColor(RGB(0x90,0x00,0xF0));
	AddSColor(RGB(0x00,0xF0,0xF0));//6

	AddSColor(RGB(0x00,0x00,0x00));
	AddSColor(RGB(0xF0,0x90,0x00));//8
	AddSColor(RGB(0xF0,0x00,0x90));

	AddSColor(RGB(0x90,0x00,0x90));//10
	AddSColor(RGB(0x90,0x00,0xF0));
	AddSColor(RGB(0x00,0xF0,0x90));//12
	AddSColor(RGB(0x90,0xF0,0x00));
	AddSColor(RGB(0x00,0x90,0x90));//14
	AddSColor(RGB(0x90,0x90,0x00));
	
	AddSColor(RGB(0x90,0x90,0xF0));//16
	AddSColor(RGB(0x90,0xF0,0x90));
	AddSColor(RGB(0xF0,0x90,0x90));//18



/*	AddSColor(RGB(0x90,0x90,0x90));//0

	AddSColor(RGB(0x00,0x00,0xFF));
	AddSColor(RGB(0x00,0xFF,0x00));//2
	AddSColor(RGB(0xFF,0x00,0x00));

	AddSColor(RGB(0x00,0x90,0x90));//4
	AddSColor(RGB(0x90,0x90,0x00));
	AddSColor(RGB(0x90,0x00,0x90));//6

	AddSColor(RGB(0x00,0xF0,0xF0));
	AddSColor(RGB(0xF0,0xF0,0x00));//8
	AddSColor(RGB(0xF0,0x00,0xF0));

	AddSColor(RGB(0x00,0x90,0xF0));//10
	AddSColor(RGB(0x90,0x00,0xF0));
	AddSColor(RGB(0x00,0xF0,0x90));//12
	AddSColor(RGB(0x90,0xF0,0x00));
	AddSColor(RGB(0xF0,0x00,0x90));//14
	AddSColor(RGB(0xF0,0x90,0x00));
	
	AddSColor(RGB(0x90,0x90,0xF0));//16
	AddSColor(RGB(0x90,0xF0,0x90));
	AddSColor(RGB(0xF0,0x90,0x90));//18

*/

/*	AddSColor(RGB(158,158,158));//0
	AddSColor(RGB(000,000,255));//2
	AddSColor(RGB(000,255,000));
	AddSColor(RGB(255,000,000));//4
	AddSColor(RGB(000,205,205));
	AddSColor(RGB(255,000,255));//6
	AddSColor(RGB(158,000,000));
  	AddSColor(RGB(050,158,255));//8
	AddSColor(RGB(255,128,000));
	AddSColor(RGB(000,000,158));//10
  	AddSColor(RGB(000,158,000));
  	AddSColor(RGB(158,158,000));//12
  	AddSColor(RGB(158,000,158));
*/	
}
void CPaletteStack::AddSColor(unsigned long newColor)
{
	m_PalStack.push_back(newColor);
	NumColors+=1;
}

unsigned long CPaletteStack::GetSColor(int ColorPos)
{
	MY_PAL_STACK::iterator m_Index;

	if (ColorPos+1>NumColors || ColorPos<0)
		return 0;
	else 
		return *(m_PalStack.begin()+ColorPos);
}

void CPaletteStack::SetSColor(int ColorPos,unsigned long newValue)
{
	//TODO
}

void CPaletteStack::SetEmpty()
{
	MY_PAL_STACK::iterator Index;
	
	m_PalStack.clear();
}


//////////////////////////////////////////////////////////////////////
// CMiniView
CMiniView::CMiniView()
{
	m_DataArea.SetValue(-10.0,10.0,10.0,-10.0);
	m_DefaultDataArea.SetValue(-10.0,10.0,10.0,-10.0);

	m_AxesX=1;
	m_AxesY=2;
	m_Focus=0;
	m_PointsSize=3;
	
	m_ClustToView = (unsigned char*) malloc(255);
	for (int i=0;i<=255;i++)
	{
		*(m_ClustToView+i) = 3;
	}
}

void CMiniView::DoSize()
{
	float x,y;
	x = m_DataArea.GetSizeX()/12;
	m_DataArea.left += x;
	m_DataArea.right -= x;

	y = m_DataArea.GetSizeY()/12;
	m_DataArea.bottom += y;
	m_DataArea.top -= y;
}

void CMiniView::SetEmpty()
{
	free (m_ClustToView);
//	free (m_PointsToView);
}
