// $Id: IsolationDist.h,v 1.2 2008/07/10 03:30:57 samn Exp $ 
#ifndef ISOLATION_DIST
#define ISOLATION_DIST

#include <vector>

using namespace std;

//compute Isolation Distance
float IsolationDist(vector<int>& vClustIDs,int iClustID,vector<float >& vFloat,int iRows,int iCols);

//compute L-Ratio of a cluster
float LRatio(vector<int>& vClustIDs,int iClustID,vector<float >& vFloat,int iRows,int iCols);

#endif
