// Cluster.cpp: implementation of the CCluster class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "wclust.h"
#include "Cluster.h"
#include "Vertex.h"
#include "Hist.h"
#include <algorithm>
#include <map>
#include "apcluster.h"

using namespace std;



#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// CCluster
CCluster::CCluster()
{ 
	undoBndry=0;//new CBoundary();//0;
	m_Count=0; 
	m_ClMode=2;
	CBoundary *Bnd;
	Bnd=new CBoundary(); 
	AddBndry(Bnd); 
	m_newChanges = 0;
	m_iInfPerClust = 12;
	memset(m_pNumClusts,0,sizeof(int)*4);
};

CCluster::CCluster(CPaletteStack *MyPalette)
{ 
	undoBndry=0;
	m_PalStack = MyPalette; 
	m_Count = 0; 
	m_ClMode = 1;
	CBoundary *Bnd;
	Bnd=new CBoundary(MyPalette); 
	AddBndry(Bnd); 
	m_newChanges = 0;
	m_iInfPerClust = 12;
	memset(m_pNumClusts,0,sizeof(int)*4);
};

//////////////////////////////////////////////////////////////////////
void CCluster::SetEmpty()
{
	MY_STACK::iterator Index;
	CBoundary *Bndr;

	for (Index=m_BndrStack.begin();Index!=m_BndrStack.end();Index++)
	{
		Bndr = (CBoundary*) *Index;
		Bndr->SetEmpty();
		delete Bndr;
	}
	m_BndrStack.clear();
	
	CParamDim *pd;
	for (Index=m_ParamDimStack.begin();Index!=m_ParamDimStack.end();Index++)
	{
		pd = (CParamDim*)*Index;
		delete pd;
	}
	m_ParamDimStack.clear();

	usedExternWCP.clear();

	m_pNumClusts[CLUST_USER] = m_Count = 0;
	m_newChanges = 0;
	ClearUNDO();
};

//////////////////////////////////////////////////////////////////////
void CCluster::Clear()
{
	MY_STACK::iterator Index;
	CBoundary *Bndr;
	m_pNumClusts[CLUST_USER] = m_Count=0;

	for (Index=m_BndrStack.begin();Index!=m_BndrStack.end();Index++)
	{
		Bndr = (CBoundary*) *Index;
		Bndr->SetEmpty();
		delete Bndr;
	}
	m_BndrStack.clear();

	
	CParamDim *pd;
	for (Index=m_ParamDimStack.begin();Index!=m_ParamDimStack.end();Index++)
	{
		pd = (CParamDim*)*Index;
		delete pd;
	}
	m_ParamDimStack.clear();

	Bndr=new CBoundary(); 
	AddBndry(Bndr);

}

//////////////////////////////////////////////////////////////////////
void CCluster::SwapPolarity(CVerxStack *Pnts)
{
	if (m_Swap)
	{
		m_Swap = 0;
	}
	else{
		m_Swap = 1;
	}
	Pnts->SwapPolarity();
	CalcParam(Pnts);
	Pnts->CalcMinMax();
	Clustering(Pnts);
	m_newChanges = 3;
}

//////////////////////////////////////////////////////////////////////
void CCluster::AddAxes(CVerxStack *Pnts,CParamDim *param)
{
	if ( param->GetType() == 2 )
	{  
//		CString *MyText = new CString("Y_ch_t=ms");
		CString *MyText = new CString("T-V()");
		char pom[5],chanel;
		sprintf(&chanel,"%d",(int) param->GetParam(2)+1);
		MyText->Insert(1,chanel);
		sprintf(pom,"%1.3f",param->GetParam(1)*1000);
		for (int i=0;i<5;i++)
		{
			MyText->Insert(5+i,pom[i]);
		}
		Pnts->AddAxes(MyText);
	}
	if ( param->GetType() == 3 )
	{
//		CString *MyText = new CString("dY_ch_t=ms");
		CString *MyText = new CString("T-dY()");
		char pom[5],chanel;
		sprintf(&chanel,"%d",(int) param->GetParam(2)+1);
		MyText->Insert(1,chanel);
		sprintf(pom,"%1.3f",param->GetParam(1)*1000);
		for (int i=0;i<5;i++)
		{
			MyText->Insert(6+i,pom[i]); 
		}
		Pnts->AddAxes(MyText);
	}
	if ( param->GetType() == 4 )
	{
//		CString *MyText = new CString("E(-)ms");
		CString *MyText = new CString("T-E(-)");
		char pom[5],chanel;
		sprintf(&chanel,"%d",(int) param->GetParam(3)+1);
		MyText->Insert(1,chanel);
		sprintf(pom,"%1.3f",param->GetParam(1)*1000);
		for (int i=0;i<5;i++)
		{
			MyText->Insert(5+i,pom[i]);
		}
		sprintf(pom,"%1.3f",param->GetParam(2)*1000);
		for (i=0;i<5;i++)
		{
			MyText->Insert(11+i,pom[i]);
		}
		Pnts->AddAxes(MyText);
	}
	if ( param->GetType() == 5 )
	{	// Parameter from file

		CString *MyText = new CString("T-");
	
		MyText->Insert(2, (LPCTSTR)  (usedExternWCP.begin() + (int) param->GetParam(1) )->paramName );
	
		char chanel;
		sprintf(&chanel,"%d",(int) param->GetParam(2)+1);
	
		MyText->Insert(1,chanel);
	
		Pnts->AddAxes(MyText);
	
	}

}

//////////////////////////////////////////////////////////////////////
void CCluster::AddParam(CMyObject *toStore, CVerxStack *Pnts)
{
	m_ParamDimStack.push_back(toStore);
	Pnts->Dimension += 1;

	CParamDim *param;
	param = (CParamDim*) toStore;

	if ( param->GetType() == 2 )
	{
		AddAxes(Pnts,param);
		CalcParamLast(Pnts);
		Pnts->CalcMinMaxLast();
	}

	if ( param->GetType() == 3 )
	{
		AddAxes(Pnts,param);
		CalcParamLast(Pnts);
		Pnts->CalcMinMaxLast();
	}

	if ( param->GetType() == 4 )
	{
		AddAxes(Pnts,param);
		CalcParamLast(Pnts);
		Pnts->CalcMinMaxLast();
	}

	if ( param->GetType() == 5 )
	{
		AddAxes(Pnts,param);
	FILE *f = fopen("a.a","a+");
	fprintf(f,"1###\n" );
	fclose(f);
		CalcParamLast(Pnts);
	f = fopen("a.a","a+");
	fprintf(f,"2###\n" );
	fclose(f);
		Pnts->CalcMinMaxLast();
	f = fopen("a.a","a+");
	fprintf(f,"3###\n" );
	fclose(f);
	}

	m_newChanges = 3;
}

//////////////////////////////////////////////////////////////////////
void CCluster::RemParam(CVerxStack *Pnts, int iNum)
{
	MY_STACK::iterator indexBndry;

	CBoundary *bndry;
	for (indexBndry = m_BndrStack.begin();indexBndry != m_BndrStack.end(); indexBndry++)
	{
		bndry = (CBoundary*) *indexBndry;
		bndry->AdaptProj(iNum + Pnts->GetBaseDimension() + 1); //9
	}
	
	MY_STACK::iterator indexPD;

	CParamDim *parDim;
	indexPD = m_ParamDimStack.begin() + iNum;
	parDim = (CParamDim*) *indexPD;
	
	if ( parDim->GetType() == 5 )
	{	// external param from file
		
		// first check, if there is more than 1 param of the candidat to delete
		int sameParams = 0;
		while ( indexPD != m_ParamDimStack.end() )
		{
			if ( ((CParamDim*)*indexPD)->GetType() == 5 )
			{
				if ( ((CParamDim*)*indexPD)->GetParam(1) == parDim->GetParam(1) )
				{
					sameParams++;
				}
			}
			indexPD++;
		}
		if ( sameParams == 1 )
		{
			usedExternWCP.erase( usedExternWCP.begin() + (int) parDim->GetParam(1) );
		}

		indexPD = m_ParamDimStack.begin() + iNum;

		Pnts->RemoveExternalParam( (int) parDim->GetParam(3) );
		while ( indexPD != m_ParamDimStack.end() )
		{
			if ( ((CParamDim*)*indexPD)->GetType() == 5 )
			{
				((CParamDim*)*indexPD)->SetParam(3, ((CParamDim*)*indexPD)->GetParam(3) - 1);
				if ( sameParams == 1 )
				{
					((CParamDim*)*indexPD)->SetParam(1, ((CParamDim*)*indexPD)->GetParam(1) - 1);
				}
			}
			indexPD++;
		}
		indexPD = m_ParamDimStack.begin() + iNum;
	}

	delete parDim;
	m_ParamDimStack.erase(indexPD);
//	CalcParam(Pnts);
//	Pnts->CalcMinMax();
//	Clustering(Pnts);
	m_newChanges = 3;
}

//////////////////////////////////////////////////////////////////////
void CCluster::RemParamZeros(CVerxStack *Pnts)
{
	int paramNo = 0;
	
	CParamDim *param;
	MY_STACK::iterator indexPD;
	indexPD = m_ParamDimStack.begin();
	while ( indexPD != m_ParamDimStack.end() )
	{
		param = (CParamDim*)*indexPD;
		if ( param->m_Type == 5 )
		{
			sWcpFiles *wcp = &*( usedExternWCP.begin() + (int)param->GetParam(1) );
			if ( wcp->fileName.Compare( "-" ) == 0 )
			{
				RemParam(Pnts, paramNo);
				RemParam(Pnts, paramNo);
				RemParam(Pnts, paramNo);
				RemParam(Pnts, paramNo);
				indexPD = m_ParamDimStack.begin(); paramNo = 0;
			}
			else {
				indexPD++;
				paramNo++;
			}
		}
		else {
			indexPD++;
			paramNo++;
		}
	}
	ClearUNDO();
}

//////////////////////////////////////////////////////////////////////
void CCluster::Draw(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,unsigned char *Clust,int style)
{
	MY_STACK::iterator Index;
	for (Index=m_BndrStack.begin();Index!=m_BndrStack.end();Index++)
	{
		(*Index)->Draw(pDC,DrawWin,whichValues,whichAxes,Clust,style);
	}
}

//////////////////////////////////////////////////////////////////////
void CCluster::SetNoise(CVerxStack *Pnts)
{
	if(!m_BndrStack.size()) return;

	//only set to noise the vertices in the most recently added boundary
	//(the one just made with the noise button)
	MY_STACK::iterator iBndry=m_BndrStack.end();
	iBndry--;
	CBoundary* Bndr = (CBoundary*) *iBndry;
	MY_STACK::iterator iPnts;
	CVertex *m_vx;

	for (iPnts = Pnts->m_VerxStack.begin(); iPnts != Pnts->m_VerxStack.end();iPnts++)
	{
		m_vx = (CVertex*)*iPnts;
		//m_vx->EmptyClust();
		//m_vx->AddClust(0);

		//if ( m_vx->GetNoise() )
		{
		//	m_vx->AddClust(255);
		}
		//else
		{	

			//Bndr->Clustering(m_vx);
			if(Bndr->IsIn(m_vx))
			{
				//m_vx->AddClust(255); //why does that cause a crash in release mode??
					                    //when double clicking on edit window after noise
										//points have been added...??
				m_vx->SetNoise(1);
			}
			else
			{
				int moo=0;
			}	
			//m_vx->SelectCluster(m_ClMode);
		}
	}
	//recalculate min,max so that noise will not contribute
	Pnts->CalcMinMax();
}

//////////////////////////////////////////////////////////////////////
void CCluster::Clustering(CVerxStack *Pnts)
{
	MY_STACK::iterator iPnts,iBndry;
	CBoundary *Bndr;
	CVertex *m_vx;

	for (iPnts = Pnts->m_VerxStack.begin(); iPnts != Pnts->m_VerxStack.end();iPnts++)
	{
		m_vx = (CVertex*)*iPnts;
		m_vx->EmptyClust();
		m_vx->AddClust(0);

		if ( m_vx->GetNoise() )
		{
			m_vx->AddClust(255);
		}
		else
		{
	
			for (iBndry = m_BndrStack.begin(); iBndry!=m_BndrStack.end(); iBndry++)
			{
				Bndr = (CBoundary*) *iBndry;
				Bndr->Clustering(m_vx);
			}
	
			m_vx->SelectCluster(m_ClMode);
		}
	}

}

//////////////////////////////////////////////////////////////////////
void CCluster::Clustering(CVertex *Pnt)
{
	MY_STACK::iterator Index;
	CBoundary *Bndr;
	
	Pnt->EmptyClust();
	Pnt->AddClust(0);

	if (Pnt->GetNoise())
	{
		Pnt->AddClust(255);
	}
	else
	{
		for (Index=m_BndrStack.begin();Index!=m_BndrStack.end();Index++)
		{
			Bndr = (CBoundary*) *Index;
			Bndr->Clustering(Pnt);
		}
		Pnt->SelectCluster(m_ClMode);
	}
}

//////////////////////////////////////////////////////////////////////
void CCluster::FindNoise(CVertex *pnt)
{
	// TODO polygons determining user noise

	

}

//////////////////////////////////////////////////////////////////////
void CCluster::FindNoise(CVerxStack *pnts)
{
	MY_STACK::iterator iVerx;

	CVertex *verx;
	for (iVerx = pnts->m_VerxStack.begin(); iVerx != pnts->m_VerxStack.end(); iVerx++)
	{
		verx = (CVertex*) *iVerx;
		FindNoise(verx);
	}
}

//////////////////////////////////////////////////////////////////////
void CCluster::CreateHeader(FILE *file,CString& strInfo)
{
	fprintf(file,"%%%%BEGIN_HEADER CLUSTER_FILE Version 1.1\n");
	fprintf(file,"\n");
	if(strInfo.GetLength()) fprintf(file,"%s",strInfo.GetString());
	fprintf(file,"%%%%BEGIN RECORD_FORMAT_INFORMATION\n");
	fprintf(file,"%%VersionIdentifier ('S')\n");
	fprintf(file,"%%VersionFormat.2 Identifier.1 VersionTimes10.1\n");
	fprintf(file,"%%ExternalParamAmountIdentifier.1 ('W')\n");
	fprintf(file,"%%ExternalParamAmountFormat.2 Identifier.1 Amount.1\n");
	fprintf(file,"%%ExternalParameterIdentifier.1 ('E')\n");
	fprintf(file,"%%ExternalWcpParameterFormat.x Identifier.1 Size.1 ParamName.Size\n");
	fprintf(file,"%%ExtendedDimensionIdentifier.1 ('D')\n");
	fprintf(file,"%%ExtendedDimensionFormat.2 Identifier.1 Size.1\n");
	fprintf(file,"%%ExtendedParameterIdentifier.1 ('R')\n");
	fprintf(file,"%%ExtendedParameterFormat.21 Identifier.1 Type.1 Parameter1.4 Parameter2.4 Parameter3.4 Parameter4.4\n");
	fprintf(file,"%%NoClusterIdentifier.1 ('C')\n");
	fprintf(file,"%%NoClusterFormat.5 Identifier.1 No.4\n");
	fprintf(file,"%%BoundaryIdentifier.1 ('B')\n");
	fprintf(file,"%%BoundaryFormat.5 Identifier.1 NoProjections.4\n");
	fprintf(file,"%%ProjectionIdentifier.1 ('P')\n");
	fprintf(file,"%%ProjectionFormat.13 Identifier.1 AxisX.4 AxisY.4 NumLines.4\n");
	fprintf(file,"%%PointIdentifier.1 ('N')\n");
	fprintf(file,"%%PointFormat.9 Identifier.1 X.4 Y.4\n");
	fprintf(file,"%%VectorIdentifier.1 ('V')\n");
	fprintf(file,"%%VectorFormat.9 Identifier.1 X.4 Y.4 b.4\n");
	fprintf(file,"%%%%END RECORD_FORMAT_INFORMATION\n\n");
	fprintf(file,"%%%%END_HEADER\t\t");
}

//////////////////////////////////////////////////////////////////////
int CCluster::ChooseFileAndStore(CString& strInfo)
{
    static char BASED_CODE szFilter[] = "Cluster Files (*.cl)|*.cl|All Files (*.*)|*.*||";
	CFileDialog dlg(FALSE, "cl", "*.cl",OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,szFilter);

	if (dlg.DoModal()==IDOK)
	{
		FILE *strFile;
		
		strFile = fopen(dlg.GetPathName(),"w");
		if ( strFile == NULL )
			return 2;
		CreateHeader(strFile,strInfo);
		
		fclose(strFile);

		CFile file;
		if (!file.Open(dlg.GetPathName(),CFile::modeWrite))
			return 2;
		else
		{
			StoreData(&file);
			file.Close();
		}
	}
	m_newChanges = 0;
	return 0;
}

//////////////////////////////////////////////////////////////////////
void CCluster::AutoSave(char *fileAS,CString& strInfo)
{
	if ( m_newChanges & 2 )
	{
		FILE *strFile;
		
		strFile = fopen(fileAS,"w");
		if ( strFile == NULL )
			return;
		CreateHeader(strFile,strInfo);
		
		fclose(strFile);

		CFile file;
		if (!file.Open(fileAS,CFile::modeWrite))
			return;
		else
		{
			StoreData(&file);
			file.Close();
		}
		m_newChanges &= 0xFD;
	}
}

//////////////////////////////////////////////////////////////////////
void CCluster::StoreData(CFile *file)
{
	MY_STACK::iterator Index;

	file->Seek(0,CFile::end);
	// Store VERSION 1.3
	char ver=13;
	file->Write("S",1); file->Write(&ver,1);
			
	// Store higher dimension
	int Dim = 0;
	for (Index = m_ParamDimStack.begin(); Index != m_ParamDimStack.end(); Index++)
	{
		Dim++;
	}
	if (Dim>0)
	{
		file->Write("W",1);
		char size = usedExternWCP.size();
		file->Write(&size,sizeof(size));
		MY_WCP_FILES_STACK::iterator indWcp;
		for ( indWcp = usedExternWCP.begin(); indWcp != usedExternWCP.end(); indWcp++ )
		{
			CString extParam = (*indWcp).paramName;
			char length = (char) extParam.GetLength();
			file->Write("E",1);
			file->Write(&length, 1);
			file->Write((LPCTSTR) extParam, length);
		}
		
		file->Write("D",1);
		file->Write(&Dim,sizeof(Dim));
		
		CParamDim *ParDim;
		for (Index = m_ParamDimStack.begin(); Index != m_ParamDimStack.end(); Index++)
		{
			ParDim = (CParamDim*) *Index;
			file->Write("R",1);
			file->Write(&ParDim->m_Type,sizeof(ParDim->m_Type));
			file->Write(&ParDim->m_Par1,sizeof(ParDim->m_Par1));
			file->Write(&ParDim->m_Par2,sizeof(ParDim->m_Par2));
			file->Write(&ParDim->m_Par3,sizeof(ParDim->m_Par3));
			file->Write(&ParDim->m_Par4,sizeof(ParDim->m_Par4));
		}
	}
			
	// Store clusters' data
	file->Write("C",1); 
	file->Write(&m_Count,sizeof(m_Count));
	CBoundary *bndr;
	for (Index=m_BndrStack.begin();Index!=m_BndrStack.end();Index++)
	{
		bndr = (CBoundary*) *Index;
		bndr->StoreData(file);
	}
}

//////////////////////////////////////////////////////////////////////
int CCluster::FindDataStartPtr(CFile *file)
{
	int nRead;
	char *buffer;
	buffer = (char*) malloc(8192);
	if (buffer==NULL)
		return 3;
	else {
		//Searching of index of binary data
		nRead=file->Read(buffer,8192);
		buffer[8191] = 0;
		
		char pomStr[20];
		sprintf(pomStr,"%%%%END_HEADER");
		char *pdest = strstr(buffer, pomStr);
		if ( pdest == NULL )
		{
			file->Close();
			free( buffer );
			return 2;
		}
					
		dataStartPtr = pdest - buffer + 1 + 13;
		free(buffer);
	}
	return 0;
}

//////////////////////////////////////////////////////////////////////
int CCluster::OpenFile(CFile *file, CVerxStack *Pnts)
{
	static char BASED_CODE szFilter[] = "Cluster Files (*.cl)|*.cl|All Files (*.*)|*.*||";
	CFileDialog dlg(TRUE, "cl", "*.cl",OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,szFilter);
	if (dlg.DoModal()==IDOK)
	{
		if (!file->Open(dlg.GetPathName(),CFile::modeRead))
			return 4;  // file is NOT OPENED
		else
		{
			SetEmpty();
			ClearUNDO();
			Pnts->ClearHighDim();
			Pnts->ClearExternalParamData();
			
			int errorNo = FindDataStartPtr(file);
			if ( errorNo !=0 )
			{
				return errorNo;
			}
			else
				file->Seek(dataStartPtr,0);

			char m_Identif;
			
			// Read version
			file->Read(&m_Identif,1);
			if ( m_Identif =='S' )
			{
				char Version;
				file->Read(&Version,1);
				file->Read(&m_Identif,1);
			}
	
			// Read external parameter info
			if ( m_Identif == 'W' )
			{
				char numWcp;
				file->Read(&numWcp,1);
				for ( char i = 0; i<numWcp; i++)
				{
					sWcpFiles wcp;
					file->Read(&m_Identif,1);
					if ( m_Identif == 'E' ) 
					{
						char length, *data;
						file->Read(&length, 1);
						data = (char*) malloc(length);
						file->Read(data,length);
						for (char j=0; j<length; j++)
						{
							wcp.paramName.Insert(j,data[j]);
						}
						free(data);
						wcp.flag = numWcp;
						usedExternWCP.push_back(wcp);
					}
					else
					{
						file->Close();
						SetEmpty();
						Pnts->ClearHighDim();
						return 2;
					}
				}
			}
			return 0; // file OPENDED
		}
	}
	return 1; // CANCEL
}

//////////////////////////////////////////////////////////////////////
int CCluster::LoadData(CFile *file, CVerxStack *Pnts)
{
	// Set file pointer to the first data identifier
	file->Seek(dataStartPtr,0);
				
	// Main reading of data
	int Count;
	char m_Identif; 
	char Version = 10;
				
	file->Read(&m_Identif,1);
	if ( m_Identif =='S' )
	{
		file->Read(&Version,1);
		file->Read(&m_Identif,1);
	}
	
	if ( m_Identif == 'W' )
	{
		char numWcp;
		file->Read(&numWcp,1);
		for ( char i = 0; i<numWcp; i++)
		{
			file->Read(&m_Identif,1);
			if ( m_Identif == 'E' ) 
			{
				char length, *data;
				file->Read(&length, 1);
				data = (char*) malloc(length*2);
				file->Read(data,length);
				free(data);
			}
		}
		file->Read(&m_Identif,1);
	}

	if ( m_Identif == 'D' )
	{	// in file are stored parameters of the higher dimensions
		file->Read(&Count,sizeof(Count));
		CParamDim *ParDim;
		for (int iI=0; iI<Count; iI++)
		{
			file->Read(&m_Identif,1);
			if (m_Identif == 'R')
			{
				ParDim = new CParamDim();
				file->Read(&ParDim->m_Type,sizeof(ParDim->m_Type));
				file->Read(&ParDim->m_Par1,sizeof(ParDim->m_Par1));
				file->Read(&ParDim->m_Par2,sizeof(ParDim->m_Par2));
				file->Read(&ParDim->m_Par3,sizeof(ParDim->m_Par3));
				file->Read(&ParDim->m_Par4,sizeof(ParDim->m_Par4));
				AddParam(ParDim,Pnts);
			}
			else {
				file->Close();
				SetEmpty();
				Pnts->ClearHighDim();
				Pnts->ClearExternalParamData();
				return 2;
			}
		}

		file->Read(&m_Identif,1);
	}
							
	if ( m_Identif == 'C' )
	{	// Clusters (only 1x in file)
		file->Read(&Count,sizeof(Count));
	}
	else {
		SetEmpty();
		Pnts->ClearHighDim();
		file->Close();
		Pnts->ClearExternalParamData();
		return 2;
	}

	int NumbLoad;
	int errorLoad;
	int bndr_Numb=0;
	CBoundary *bndr;
	for (int i=0;i<Count;i++)
	{ 
		NumbLoad=file->Read(&m_Identif,1);
		if (NumbLoad!=1)
		{
			Pnts->ClearHighDim();
			SetEmpty();
			file->Close();
			Pnts->ClearExternalParamData();
			return 2;
		}
		if (m_Identif=='B')
		{	//Boundary
			bndr = new CBoundary(m_PalStack);
			bndr->m_Numb=bndr_Numb;
			AddBndry(bndr);
			bndr_Numb++;
			if (m_Count>0) errorLoad=bndr->LoadData(file,Version);
			if (errorLoad)
			{
				SetEmpty();	
				Pnts->ClearHighDim();
				file->Close();
				Pnts->ClearExternalParamData();
				return errorLoad;
			}
		}
		else {
			Pnts->ClearHighDim();
			SetEmpty();
			file->Close();
			Pnts->ClearExternalParamData();
			return (int) m_Identif;
		}
	}
	file->Close();
	m_newChanges = 0;
	return 0;
}

// For only one spike (which will be stored)
void CCluster::CalcParamOneSpike(CVerxStack *Pnts, CVertex *Pnt, sSpike *spike)
{
	MY_STACK::iterator Index, IndParD;
	
//	Pnts->forStoreBPF_NonClVx->ClearHighDim(Pnts->BASE_DIMENSION);
	Pnt->ClearHighDim(Pnts->BASE_DIMENSION);
	
	CParamDim *param;
	for (IndParD=m_ParamDimStack.begin();IndParD!=m_ParamDimStack.end();IndParD++)
	{
		param = (CParamDim*) *IndParD;
		Pnt->CalcParam(param,Pnts->m_x,Pnts->SAMPLE_FREQ,Pnts->NUM_SAMPLES, spike);
	}
}


void CCluster::CalcParam(CVerxStack *Pnts)
{
	MY_STACK::iterator IndParD;
	MY_SPIKE_STACK::iterator indSpikes;
	
	Pnts->ClearHighDim();
	
	sSpike	*spike;
	CVertex *verx;
	CParamDim *param;
	for (IndParD=m_ParamDimStack.begin();IndParD!=m_ParamDimStack.end();IndParD++)
	{
		param = (CParamDim*) *IndParD;
		AddAxes(Pnts,param);
		for ( indSpikes = Pnts->m_SpikesStack.begin(); indSpikes != Pnts->m_SpikesStack.end(); indSpikes++ )
		{
			spike = (sSpike*) *indSpikes;
			if ( spike->type == 1)
			{
				verx = (CVertex*) *( Pnts->m_VerxStack.begin() + spike->offset );
				verx->CalcParam(param,Pnts->m_x,Pnts->SAMPLE_FREQ,Pnts->NUM_SAMPLES, spike);
			}
		}
	}
	Pnts->Dimension += m_ParamDimStack.size();


/*
	MY_STACK::iterator Index, IndParD;
	
	Pnts->ClearHighDim();
	CVertex *verx;
	
	CParamDim *param;
	for (IndParD=m_ParamDimStack.begin();IndParD!=m_ParamDimStack.end();IndParD++)
	{
		param = (CParamDim*) *IndParD;
		AddAxes(Pnts,param);
		for (Index=Pnts->m_VerxStack.begin();Index!=Pnts->m_VerxStack.end();Index++)
		{
			verx = (CVertex*) *Index;
			verx->CalcParam(param,Pnts->m_x,Pnts->SAMPLE_FREQ,Pnts->NUM_SAMPLES);
		}
	}
	Pnts->Dimension += m_ParamDimStack.size();
*/
//	Pnts->CalcMinMax();
}

//////////////////////////////////////////////////////////////////////
void CCluster::CalcParamLast(CVerxStack *Pnts)
{
	MY_SPIKE_STACK::iterator indSpikes;
	MY_STACK::iterator IndParD;
	
	CVertex *verx;
	sSpike *spike;
	IndParD = m_ParamDimStack.end()-1;
	for ( indSpikes = Pnts->m_SpikesStack.begin(); indSpikes != Pnts->m_SpikesStack.end(); indSpikes++ )
	{
//FILE *f = fopen("a.a","a+");
//fprintf(f,"a\n" );
//fclose(f);
		spike = (sSpike*) *indSpikes;
		if ( spike->type == 1)
		{
//f = fopen("a.a","a+");
//fprintf(f,"e" );
//fclose(f);
			verx = (CVertex*) *( Pnts->m_VerxStack.begin() + spike->offset );
//f = fopen("a.a","a+");
//fprintf(f,"i" );
//fclose(f);		
			CParamDim *param;
//f = fopen("a.a","a+");
//fprintf(f,"o" );
//fclose(f);
			param = (CParamDim*) *IndParD;
//f = fopen("a.a","a+");
//fprintf(f,"u %d,%d p %d,%d,%d,%d,%d", spike->type, spike->offset,param->m_Type, param->m_Par1,param->m_Par2,param->m_Par3,param->m_Par4);
//fclose(f);
			verx->CalcParam(param,Pnts->m_x,Pnts->SAMPLE_FREQ,Pnts->NUM_SAMPLES, spike);
//f = fopen("a.a","a+");
//fprintf(f,"y\n" );
//fclose(f);
		}
	}

/*	
	MY_STACK::iterator Index, IndParD;
	
	CVertex *verx;
	IndParD = m_ParamDimStack.end()-1;
	for (Index=Pnts->m_VerxStack.begin();Index!=Pnts->m_VerxStack.end();Index++)
	{
		verx = (CVertex*) *Index;
		
		CParamDim *param;
		param = (CParamDim*) *IndParD;
		verx->CalcParam(param,Pnts->m_x,Pnts->SAMPLE_FREQ,Pnts->NUM_SAMPLES);
	}
*/
//	Pnts->CalcMinMaxLast();
}

//////////////////////////////////////////////////////////////////////
char CCluster::IsUNDO()
{ 
	if ( undoBndry != NULL )
		return 1; // UNDO can be used
	else
		return 0; // UNDO is empty
}

//////////////////////////////////////////////////////////////////////
void CCluster::ClearUNDO()
{
	if ( IsUNDO() )
	{
		undoType = 0;
		undoBndry->SetEmpty();
		delete undoBndry;
		undoBndry = NULL;
	}
}

/////////////////////////////////////////////////////
// MakeUNDO - type: 0-none, 1-change, 2-insert (after removing)
void CCluster::MakeUNDO(int cluster, char type)
{
	// create data for UNDO parameters
	ClearUNDO();

	MY_STACK::iterator IndBndr, IndProj, IndPnt2D, IndVect2D;

	CBoundary *mainBndr;
	CProjection *newProj;
	CPoint2D *newPnt2D;
	CVect2D *newVect2D;

	if ( cluster>0 )
	{
		undoType = type;
		IndBndr = (m_BndrStack.begin() + cluster);
		mainBndr = (CBoundary*) *IndBndr;

		undoBndry = new CBoundary(m_PalStack);
		undoBndry->m_Numb = mainBndr->m_Numb;

		for (IndProj=mainBndr->m_ProjStack.begin();IndProj!=mainBndr->m_ProjStack.end();IndProj++)
		{

			newProj = new CProjection(m_PalStack);
			newProj->m_AxesX = ((CProjection*) *IndProj)->m_AxesX;
			newProj->m_AxesY = ((CProjection*) *IndProj)->m_AxesY;
			undoBndry->AddProj(newProj);

			for (IndPnt2D=((CProjection*)*IndProj)->m_Pnt2DStack.begin();IndPnt2D!=((CProjection*)*IndProj)->m_Pnt2DStack.end();IndPnt2D++)
			{
				newPnt2D = new CPoint2D();
				newPnt2D->m_X = ((CPoint2D*) *IndPnt2D)->m_X;
				newPnt2D->m_Y = ((CPoint2D*) *IndPnt2D)->m_Y;
				newProj->AddPnt2D(newPnt2D);
			}
			
			for (IndVect2D=((CProjection*)*IndProj)->m_Vect2DStack.begin();IndVect2D!=((CProjection*)*IndProj)->m_Vect2DStack.end();IndVect2D++)
			{
				newVect2D = new CVect2D();
				newVect2D->m_X = ((CVect2D*) *IndVect2D)->m_X;
				newVect2D->m_Y = ((CVect2D*) *IndVect2D)->m_Y;
				newVect2D->m_b = ((CVect2D*) *IndVect2D)->m_b;
				newProj->AddVect2D(newVect2D);
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////
void CCluster::UNDO()
{
	MY_STACK::iterator index;
	CBoundary *bndry;
	
	if ( undoType == 1 )
	{
		// change - after DRAW, REMOVE POLY
		int position = 0;
		index = m_BndrStack.begin();
		bndry = (CBoundary*) *index;
		while ( undoBndry->m_Numb != bndry->m_Numb && index != m_BndrStack.end() )
		{
			index++;
			bndry = (CBoundary*) *index;
			position++;
		}

		if ( index != m_BndrStack.end() )
		{
			bndry->SetEmpty();
			m_BndrStack.erase(index);
			delete bndry;

			m_BndrStack.insert(m_BndrStack.begin()+position,undoBndry);
			
			undoBndry = NULL;
			undoType = 0;
		}
	}

	if ( undoType == 2 )
	{
		// insert - after REMOVE ALL
		index = m_BndrStack.begin() + undoBndry->m_Numb;

		m_BndrStack.insert(index, undoBndry);

		undoBndry = NULL;
		undoType = 0;

		int newI=0;
		for (index = m_BndrStack.begin(); index != m_BndrStack.end(); index++)
		{
			bndry = (CBoundary*) *index;
			bndry->m_Numb = newI;
			newI++;
		}
		m_Count++;
	}
	if ( undoType == 3 )
	{
		// remove - after CREATE NEW, COPY

		MY_STACK::iterator Index,IndProj;
	
		int Selected;
		int i;
		int nalezen=0,counter=0;
		CBoundary *MyBoundary;

		Selected = undoBndry->m_Numb + 1;
		Selected = (Selected == 0) ? 255 : (Selected - 1);

		if (Selected>0 && Selected < 255)
		{
			CBoundary *Bndr =(CBoundary*) *(m_BndrStack.begin() + Selected);
			m_BndrStack.erase(m_BndrStack.begin()+Selected);
			m_Count -= 1;
			delete Bndr;
			i = Selected;
			for ( Index = (m_BndrStack.begin() + Selected); Index != m_BndrStack.end(); Index++ )
			{
				MyBoundary = (CBoundary*)*Index;
				MyBoundary->m_Numb=i;
				i++;
				Selected++;
			}
			ClearUNDO();
		}
	}

	m_newChanges = 3;
}

void CCluster::CalcClusterInfo(CVerxStack& DataStack)
{
	extern int pBins[4];
	int k = 0;

	int iClusts = GetCount() , iC=1;

	switch(DataStack.whichDraw)
	{
	case CLUST_USER:
		iClusts = GetCount();
		break;
	case CLUST_ORIG:
		iClusts = DataStack.m_NumOriginalCl;
		break;
	case CLUST_KM:
	case CLUST_INFO:
	case CLUST_AP:
		iClusts = m_pNumClusts[DataStack.whichDraw];
		break;
	}

	int iDims=DataStack.GetDimension() - 1, iD=0;

	m_vInfo[DataStack.whichDraw] = vector< vector<double> >(iClusts+1);
	for(iC=1;iC<=iClusts;iC++) m_vInfo[DataStack.whichDraw][iC] = vector<double>(m_iInfPerClust);

	//fill distributions once for each number of bins
	vector< vector<Hist> > vDistribs[4];
	for(k=0;k<4;k++) FillDistribs(DataStack,*this,pBins[k],vDistribs[k],iClusts+1,DataStack.whichDraw);

	//inclusive information gain
	for(k=0;k<4;k++)
	{		
		vector<double> vcInf(iClusts+1);
		for(iC=1;iC<=iClusts;iC++)
		{
			double kldiv=0.0;
			for(iD=0;iD<iDims;iD++)
			{
				kldiv += KLDiv(vDistribs[k][iC][iD],vDistribs[k][iClusts+1][iD]);
			}
			m_vInfo[DataStack.whichDraw][iC][k]=kldiv;
		}
	}
	//approximate exclusive information gain
	for(k=4;k<8;k++)
	{		
		vector<double> vcInf(iClusts+1);
		for(iC=1;iC<=iClusts;iC++)
		{
			double kldiv=0.0;
			for(iD=0;iD<iDims;iD++)
			{
				kldiv += KLDivApproxExclusiveProb(vDistribs[k-4][iC][iD],vDistribs[k-4][iClusts+1][iD]);
			}
			m_vInfo[DataStack.whichDraw][iC][k]=kldiv;
		}
	}

	//uniqueness+distance distance measure
	for(k=8;k<12;k++)
	{
		vector<double> vcInf(iClusts+1);
		vector< vector<double> > vcInfInter;
		CalcUDDist(vDistribs[k-8],iClusts,vcInf,vcInfInter);
		for(iC=1;iC<=iClusts;iC++) m_vInfo[DataStack.whichDraw][iC][k]=vcInf[iC];
	}
}

void CCluster::KmeansClust(CVerxStack& DataStack,int iClusts)
{
	int iDims=DataStack.GetDimension() - 1, iD=0;

	m_pNumClusts[CLUST_KM] = iClusts;

	RandAssign(DataStack,*this,iClusts,CLUST_KM);

	vector< vector<double> > vMeans(iClusts+1);
	vector<int> vCounts(iClusts+1);

	int i = 0;
	
	while(true)
	{
		//compute centroids
		CVertex* verx;

		//init counts
		vCounts = vector<int>(iClusts+1);
		//init centroids
		for(i=1;i<=iClusts;i++) vMeans[i] = vector<double>(iDims);

		MY_STACK::iterator Index;	
		for (Index=DataStack.m_VerxStack.begin();Index!=DataStack.m_VerxStack.end();Index++)
		{	
			CVertex* verx = (CVertex*)*Index;

			//skip noise
			if(verx->GetNoise()) continue;

			for(iD=0;iD<iDims;iD++) vMeans[verx->GetKmeansClust()][iD] += verx->GetValue(iD+1);

			vCounts[verx->GetKmeansClust()]++;
		}

		for(i=1;i<=iClusts;i++)
		{
			if(vCounts[i])
			{
				for(iD=0;iD<iDims;iD++)
				{
					vMeans[i][iD] /= (double) vCounts[i];
				}
			}
		}

		//re-assign points
		bool bMoved = false;
		for (Index=DataStack.m_VerxStack.begin();Index!=DataStack.m_VerxStack.end();Index++)
		{	
			CVertex* verx = (CVertex*)*Index;

			//skip noise
			if(verx->GetNoise()) continue;

			vector<double> vDist(iClusts+1);
			for(i=1;i<=iClusts;i++)
			{
				for(iD=0;iD<iDims;iD++)
				{
					double dVal = verx->GetValue(iD+1) - vMeans[i][iD];
					vDist[i] += dVal * dVal;
				}
			}
			int iBestClust = 1;
			double dDist = vDist[iBestClust];
			for(i=2;i<=iClusts;i++)
			{
				if(vDist[i] < dDist && vCounts[i])
				{
					dDist = vDist[i];
					iBestClust = i;
				}
			}
			if(iBestClust != verx->GetKmeansClust())
			{
				verx->SetKmeansClust(iBestClust);
				bMoved = true;
			}
		}
		//didn't move any spikes, so we're done
		if(!bMoved) break;
	}
}

void CCluster::ExclusiveInfoClust(CVerxStack& DataStack,int iClusts)
{	
	extern int pBins[4];
	int k = 0;

	int iDims=DataStack.GetDimension() - 1, iD=0;

	vector< double > vInfo(iClusts+1);
/*
	KmeansClust(DataStack,pMainPal,iClusts);
	MY_STACK::iterator Index;	
	for (Index=DataStack.m_VerxStack.begin();Index!=DataStack.m_VerxStack.end();Index++)
	{
		((CVertex*)*Index)->m_InfoClust = ((CVertex*)*Index)->m_KmeansClust;
	}	
*/
	m_pNumClusts[CLUST_INFO] = iClusts;

	RandAssign(DataStack,*this,iClusts,CLUST_INFO);

	//fill distributions once
	vector< vector< Hist > > vDistribs;
	FillDistribs(DataStack,*this,pBins[0],vDistribs,iClusts+1,CLUST_INFO);

	int iV = 0;

	//approximate exclusive information gain
	vector<double> vcInf(iClusts+1);

	//only need this for first time, since its recalculated for distributions who's
	//points change, when they change...will remove it later
	int iC;
	for(iC=1;iC<=iClusts;iC++)
	{
		double kldiv=0.0;
		for(iD=0;iD<iDims;iD++)
		{
			kldiv += KLDivApproxExclusiveProb(vDistribs[iC][iD],vDistribs[iClusts+1][iD]);
		}
		vcInf[iC]=kldiv;
	}

	while(true)
	{
		bool bMoved = false;

		MY_STACK::iterator Index;	
		for (Index=DataStack.m_VerxStack.begin();Index!=DataStack.m_VerxStack.end();Index++)
		{	
			CVertex* verx = (CVertex*)*Index;

			//skip noise spikes
			if(verx->GetNoise()) continue;

			vector<double> vGains(iClusts+1);
			int iOrig = verx->GetInfoClust() , iT = 1;
			
			//move vertex OUT of original distribution
			for(iD=0;iD<iDims;iD++) vDistribs[iOrig][iD].DecBinVal(verx->GetValue(iD+1));
			
			double dGainOut = 0.0;			
			//calculate NET gain from moving vertex OUT of original distribution
			for(iD=0;iD<iDims;iD++) dGainOut += KLDivApproxExclusiveProb(vDistribs[iOrig][iD],vDistribs[iClusts+1][iD]);
			dGainOut -= vcInf[iOrig];

			for(iT=1;iT<=iClusts;iT++)
			{
				if(iT == iOrig) continue;

				//move vertex INTO temporary distribution
				for(iD=0;iD<iDims;iD++) vDistribs[iT][iD].IncBinVal(verx->GetValue(iD+1));

				//calculate NET gain from moving vertex INTO temp distribution
				double dGainIn=0.0;
				for(iD=0;iD<iDims;iD++) dGainIn += KLDivApproxExclusiveProb(vDistribs[iT][iD],vDistribs[iClusts+1][iD]);
				dGainIn -= vcInf[iT];
				
				vGains[iT] = dGainOut + dGainIn;

				//move vertex OUT of temporary distribution
				for(iD=0;iD<iDims;iD++) vDistribs[iT][iD].DecBinVal(verx->GetValue(iD+1));
			}

			//now see if moving the vertex to a different cluster had any net positive information gain
			int iMaxInd = iOrig; double dMaxGain = 0.0;
			for(iT=1;iT<=iClusts;iT++)
			{
				if(iT==iOrig) continue;
				if(vGains[iT] > dMaxGain)
				{
					dMaxGain = vGains[iT];
					iMaxInd = iT;
					bMoved = true; //moved a point
				}
			}

			if(iMaxInd != iOrig)
			{
				verx->SetInfoClust(iMaxInd);
				
				//move vertex INTO destination distribution
				for(iD=0;iD<iDims;iD++) vDistribs[iMaxInd][iD].IncBinVal(verx->GetValue(iD+1));
				
				//recalculate information gain for the two distributions that were effected...
				//"new" distribution
				double kldiv=0.0;
				for(iD=0;iD<iDims;iD++)
				{
					kldiv += KLDivApproxExclusiveProb(vDistribs[iMaxInd][iD],vDistribs[iClusts+1][iD]);
				}
				vcInf[iMaxInd]=kldiv;
				
				//original distribution
				kldiv=0.0;
				for(iD=0;iD<iDims;iD++)
				{
					kldiv += KLDivApproxExclusiveProb(vDistribs[iOrig][iD],vDistribs[iClusts+1][iD]);
				}
				vcInf[iOrig]=kldiv;
			}
			else //put it back into original distribution
			{
				for(iD=0;iD<iDims;iD++) vDistribs[iOrig][iD].IncBinVal(verx->GetValue(iD+1));
			}
		}
		//didn't move any vertices, so done
		if(!bMoved) break;
	}
}

void CCluster::APClust(CVerxStack& DataStack,int iIter,int iConvIter,double dDamp,double dPref)
{
	{
	//get vertices with values normalized btwn 0 and 1
	vector< vector<float> > vN;	
	DataStack.NormalizedV(vN,true);
	
	int iRows = vN.size();
	int iCols = vN[0].size();
	
	//similarity matrix
	vector< vector<float> > vSim(iRows);
	
	unsigned long i,j;
	//allocate memory for similarity matrix
	for(i=0;i<iRows;i++) vSim[i] = vector<float>(iRows);
	
	//compute similarity matrix
	for(i=0;i<iRows;i++)
	{
		for(j=0;j<iRows;j++)
		{
			if(i==j)
			{
				vSim[i][j] = 0.0;
			}
			else
			{
				int k;
				for(k=0;k<iCols;k++)
				{
					float dVal = vN[i][k] - vN[j][k];
					vSim[i][j] -= dVal * dVal;
				}
			}
		}
	}

	for(i=0;i<iRows;i++) vN[i].clear();
	vN.clear();
	vN=vector< vector<float> >();

	//compute preferences, set it to median of similarity values * dPref
	vector<float> vTmp(iRows*iRows);
	int k = 0;
	for(i=0;i<iRows;i++)
	{
		for(j=0;j<iRows;j++)
		{
			vTmp[k++] = vSim[i][j];
		}
	}
	std::sort(vTmp.begin(),vTmp.end());
	float dMed = vTmp[vTmp.size()/2];
	vTmp.clear();
	//vector<float> vPref(iRows);
	//for(i=0;i<iRows;i++) vPref[i] = dMed;

	FILE* fp = fopen("__tmp__wclust_sims.txt","w");
	//i k s (index i, index k, similarity between i and k)
	for(i=0;i<iRows;i++)
	{
		for(j=0;j<iRows;j++)
		{
			if(i==j) continue;
			fprintf(fp,"%d %d %f\n",i+1,j+1,vSim[i][j]);
		}
	}
	fclose(fp);

	fp = fopen("__tmp__wclust_prefs.txt","w");
	for(i=0;i<iRows;i++)
		fprintf(fp,"%f\n",dMed*dPref);
	fclose(fp);
	}

	vector<int> vIDs;

	int argc = 7;

	char tmpIter[128];
	sprintf(tmpIter,"%d",iIter);

	char tmpConvIter[128];
	sprintf(tmpConvIter,"%d",iConvIter);

	char tmpDamp[128];
	sprintf(tmpDamp,"%f",dDamp);

	char* argv[7] = {"jnk","__tmp__wclust_sims.txt","__tmp__wclust_prefs.txt","__tmp__wclust_ap_out.txt",tmpIter,tmpConvIter,tmpDamp};

	apcluster_main(argc,argv,vIDs);

	int iV = 0;

	map<int,int> oMap;

	int idx = 0;

	typedef pair<int,int> int_pair;

	for(iV=0;iV<vIDs.size();iV++)
	{
		if(oMap.find(vIDs[iV])==oMap.end())
		{
			oMap.insert( int_pair(vIDs[iV],++idx ) );
		}
	}

	MY_STACK::iterator Index;	
	iV = 0;
	for (Index=DataStack.m_VerxStack.begin();Index!=DataStack.m_VerxStack.end();Index++)
	{	
		CVertex* verx = (CVertex*)*Index;

		//skip noise
		if(verx->GetNoise()) continue;

		std::map<int,int>::iterator IT = oMap.find(vIDs[iV]);

		verx->SetAPClust(IT->second);

		iV++;
	}

	map<int,int>::iterator IT = oMap.begin();
	int idxmax = 0;
	for(;IT!=oMap.end();IT++) if(IT->second>idxmax) idxmax=IT->second;

	m_pNumClusts[CLUST_AP] = idxmax;
}

void CCluster::ResistorInfoClust(CVerxStack& DataStack,int iClusts)
{
	extern int pBins[4];
	int k = 0;

	int iDims=DataStack.GetDimension() - 1, iD=0;

	vector< double > vInfo(iClusts+1);

	//fill distributions once
	vector< vector< Hist > > vDistribs;
	RandAssign(DataStack,*this,iClusts,CLUST_INFO);

	FillDistribs(DataStack,*this,pBins[0],vDistribs,iClusts+1,CLUST_INFO);

	//information gain
	vector<double> vcInf(iClusts+1);

	m_pNumClusts[CLUST_INFO] = iClusts;

	vector< vector<double> > vcInfInter(iClusts+1);
	int iC=1;
	for(iC=1;iC<=iClusts;iC++) vcInfInter[iC] = vector<double>(iClusts+1);

	//only need this for first time, since its recalculated for distributions who's
	//points change, when they change
	CalcUDDist(vDistribs,iClusts,vcInf,vcInfInter);

	vector<int> vFrom, vTo , vMoveID;

	int iMaxIter = 30;

	int iIter = 0;

	while(true)
	{
		bool bMoved = false;

		MY_STACK::iterator Index;	
		for (Index=DataStack.m_VerxStack.begin();Index!=DataStack.m_VerxStack.end();Index++)
		{	
			CVertex* verx = (CVertex*)*Index;

			//skip noise
			if(verx->GetNoise()) continue;

			vector<double> vcInfTmp(iClusts+1), vGains(iClusts+1);
			vector< vector<double> > vcInfInterTmp;
			int iOrig = verx->GetInfoClust() , iT = 0;
			
			//move vertex OUT of original distribution
			for(iD=0;iD<iDims;iD++) vDistribs[iOrig][iD].DecBinVal(verx->GetValue(iD+1));

			//double dSumOrig = Sum(vcInf);
			double dAvgOrig = Avg(vcInf);
						
			for(iT=1;iT<=iClusts;iT++)
			{
				if(iT == iOrig) continue;

				//move vertex INTO temporary distribution
				for(iD=0;iD<iDims;iD++) vDistribs[iT][iD].IncBinVal(verx->GetValue(iD+1));

				//calculate NET gain from moving vertex OUT of original distribution and INTO temp distribution
				CalcUDDist(vDistribs,iClusts,vcInfTmp,vcInfInterTmp);
				
				vGains[iT] = Avg(vcInfTmp) - dAvgOrig;//Sum(vcInfTmp) - dSumOrig;//vcInfTmp[iOrig] - vcInf[iOrig] + vcInfTmp[iT] - vcInf[iT]; //Sum(vcInfTmp);

				//move vertex OUT of temporary distribution
				for(iD=0;iD<iDims;iD++) vDistribs[iT][iD].DecBinVal(verx->GetValue(iD+1));
			}

			//now see if moving the vertex to a different cluster had any net positive information gain
			int iMaxInd = iOrig; double dMaxGain = 0.0;
			for(iT=1;iT<=iClusts;iT++)
			{
				if(vGains[iT] > dMaxGain)
				{
					dMaxGain = vGains[iT];
					iMaxInd = iT;
				}
			}

			if(iMaxInd != iOrig)
			{
				bMoved = true; //moved a point

				verx->SetInfoClust(iMaxInd);
				
				//move vertex INTO destination distribution
				for(iD=0;iD<iDims;iD++) vDistribs[iMaxInd][iD].IncBinVal(verx->GetValue(iD+1));

				//recalculate information gain for the distributions
				//any of them could have been effected
				CalcUDDist(vDistribs,iClusts,vcInf,vcInfInter);				
			}
			else //put it back into original distribution
			{
				for(iD=0;iD<iDims;iD++) vDistribs[iOrig][iD].IncBinVal(verx->GetValue(iD+1));
			}
		}
		//didn't move any points, so we're finished
		if(!bMoved) break;

		iIter++;

		//if(iMaxIter > 0 && iIter >= iMaxIter) break;
	}
}

void CCluster::GetClusterInfo()
{
}

//////////////////////////////////////////////////////////////////////
// CProjection
void CProjection::Draw(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,int Color,int style)
{
	int x1=0,y1=0,x2=0,y2=0,x0=0,y0=0;
	int Inverse=0;
	float fx0=0.0f,fy0=0.0f,fx1=0.0f,fy1=0.0f,fx2=0.0f,fy2=0.0f,pom=0.0f;
	
	MY_STACK::iterator Index;
	CPoint2D *MyPoint;
		
	if ((whichAxes.x==m_AxesX&&whichAxes.y==m_AxesY)||(whichAxes.x==m_AxesY&&whichAxes.y==m_AxesX))
	{
		Inverse=0;
		if (whichAxes.x==m_AxesY&&whichAxes.y==m_AxesX)
			Inverse=1;
		
		CPen newPen(PS_SOLID,1,m_PalStack->GetSColor(Color));//(COLORREF)0);
		CPen *pOldPen=pDC->SelectObject(&newPen);

		if (m_Pnt2DStack.begin()!=m_Pnt2DStack.end())
		{
			int DrawIt;
			for (Index=m_Pnt2DStack.begin();Index!=m_Pnt2DStack.end();Index++)
			{	
				if (Index == m_Pnt2DStack.end()-1)
				{
					MyPoint=(CPoint2D*) (*(Index));
				}
				else MyPoint=(CPoint2D*) (*Index);

				MyPoint->GetValue(&fx1,&fy1);
				if (Inverse) { pom=fx1; fx1=fy1; fy1=pom; }

				if (Index==m_Pnt2DStack.begin())
					{ x0=x1; y0=y1; fx0=fx1; fy0=fx1; }
			
				Index++;
				
				if (Index == m_Pnt2DStack.end())
				{
					MyPoint = (CPoint2D*) (*m_Pnt2DStack.begin());
				}
				else MyPoint=(CPoint2D*) (*Index);
				MyPoint->GetValue(&fx2,&fy2);
				if (Inverse) { pom=fx2; fx2=fy2; fy2=pom; }
				Index--;
/////
				DrawIt = 0;
				int State = 0;
				if ( fx2<whichValues->left || fx2>whichValues->right || fy2<whichValues->bottom || fy2>whichValues->top )
					State = 2;
				if ( fx1<whichValues->left || fx1>whichValues->right || fy1<whichValues->bottom || fy1>whichValues->top )
					State += 1;
				if (State>0)
				{
					if (State == 1)
					{	// swap xy1 <-> xy2
						float fxp,fyp;
						fxp = fx1; fyp = fy1;
						fx1 = fx2; fy1 = fy2;
						fx2 = fxp; fy2 = fyp;
					}
					
					// Parametrize
					// x = X1 + xv.t
					float fxv,fyv,t,tm;
					fxv = fx2 - fx1;
					fyv = fy2 - fy1;

					if (State < 3)
					{
						if (fyv == 0) //  - line
						{
							if (fx2 > whichValues->right)
								fx2 = whichValues->right;
							if (fx2 < whichValues->left)
								fx2 = whichValues->left;
							DrawIt = 1;
						}
						else if (fxv == 0) //  | line
						{
							if (fy2 > whichValues->top)
								fy2 = whichValues->top;
							if (fy2 < whichValues->bottom)
								fy2 = whichValues->bottom;
							DrawIt = 1;
						}
						else // not | or - line
						{
							if (fx2>fx1)
							{
								tm = (whichValues->right - fx1) / fxv;
								if (tm>0 && tm<=1)
								{
									t = tm;
								}
								else t=5;

								tm = (whichValues->bottom - fy1)  / fyv;
								if (tm>0 && tm<=1)
								{
									if (tm<t)
										t = tm;
								}

								tm = (whichValues->top - fy1) / fyv;
								if (tm>0 && tm<=1)
								{
									if (tm<t)
										t = tm;
								}
								fx2 = fx1 + fxv*t;
								fy2 = fy1 + fyv*t;
								DrawIt = 1;
							}
							else 
							{
								tm = (whichValues->left - fx1) / fxv;
								if (tm>0 && tm<=1)
								{
									t = tm;
								}
								else t=5;

								tm = (whichValues->bottom - fy1) / fyv;
								if (tm>0 && tm<=1)
								{
									if (tm<t)
										t = tm;
								}

								tm = (whichValues->top - fy1) / fyv;
								if (tm>0 && tm<=1)
								{
									if (tm<t)
										t = tm;
								}
								fx2 = fx1 + fxv*t;
								fy2 = fy1 + fyv*t;
								DrawIt = 1;
							}
						}
					}

					if (State == 3)
					{
						if (fyv == 0) //  - line
						{
							if (fy1 > whichValues->bottom &&  fy1 < whichValues->top && (fx1<whichValues->left && fx2>whichValues->right || fx2<whichValues->left && fx1>whichValues->right) )
							{
								fx1 = whichValues->left;
								fx2 = whichValues->right;
								DrawIt = 1;
							}
						}
						else if (fxv == 0) //  | line
						{
							if (fx1 > whichValues->left && fx1 < whichValues->right && (fy1<whichValues->bottom && fy2>whichValues->top || fy2<whichValues->bottom && fy1>whichValues->top))
							{
								fy1 = whichValues->bottom;
								fy2 = whichValues->top;
								DrawIt = 1;
							}
						}
						else // not | or - line
						{
							int NumFound = 0;
							float px,py;
							float tt[2];
							
							// left
							tm = (whichValues->left - fx1) / fxv;
							if (tm>0 && tm<=1) 
							{
								py = fy1 + fyv*tm;
								if (py >= whichValues->bottom && py <= whichValues->top)
								{
									tt[NumFound] = tm;
									NumFound ++;
								}
							}

							// bottom
							tm = (whichValues->bottom - fy1) / fyv;
							if (tm>0 && tm<=1) 
							{
								px = fx1 + fxv*tm;
								if (px > whichValues->left && px < whichValues->right)
								{
									tt[NumFound] = tm;
									NumFound++;
								}
							}

							// right
							tm = (whichValues->right - fx1) / fxv;
							if (tm>0 && tm<=1) 
							{
								py = fy1 + fyv*tm;
								if (py >= whichValues->bottom && py <= whichValues->top)
								{
									tt[NumFound] = tm;
									NumFound ++;
								}
							}

							// top
							tm = (whichValues->top - fy1) / fyv;
							if (tm>0 && tm<=1) 
							{
								px = fx1 + fxv*tm;
								if (px > whichValues->left && px < whichValues->right)
								{
									tt[NumFound] = tm;
									NumFound++;
								}
							}
						
							if (NumFound == 2)
							{
								fx2 = fx1 + fxv * tt[0];
								fy2 = fy1 + fyv * tt[0];
								fx1 = fx1 + fxv * tt[1];
								fy1 = fy1 + fyv * tt[1];
								DrawIt = 1;
							}
						}
					}
				}
				else DrawIt = 1; // State == 0

/////
				if (DrawIt)
				{
					x1=DrawWin.left+(fx1-whichValues->GetLeft())*(DrawWin.right-DrawWin.left)/whichValues->GetSizeX();
					y1=DrawWin.bottom+(fy1-whichValues->GetBottom())*(DrawWin.top-DrawWin.bottom)/whichValues->GetSizeY();
					
					x2=DrawWin.left+(fx2-whichValues->GetLeft())*(DrawWin.right-DrawWin.left)/whichValues->GetSizeX();
					y2=DrawWin.bottom+(fy2-whichValues->GetBottom())*(DrawWin.top-DrawWin.bottom)/whichValues->GetSizeY();
				
					pDC->MoveTo(x1,y1);
					pDC->LineTo(x2,y2);
				}

			}
		}
		pDC->SelectObject(pOldPen);
	}
}

int CProjection::AdaptAxes(int numb)
{
	if (m_AxesX == numb || m_AxesY == numb)
		return 1;
	
	if (m_AxesX > numb)
		m_AxesX -= 1;
	if (m_AxesY > numb)
		m_AxesY -= 1;
	
	return 0;
}

float CProjection::FindMinX()
{
	MY_STACK::iterator Index;
	float Value;
	CPoint2D *Pnt2D;
	Pnt2D = (CPoint2D*) *m_Pnt2DStack.begin();
	Value = Pnt2D->m_X;
	for (Index=m_Pnt2DStack.begin();Index!=m_Pnt2DStack.end();++Index)
	{
		Pnt2D = (CPoint2D*) *Index;
		if ( Pnt2D->m_X < Value )
			Value = Pnt2D->m_X;
	}
	return Value;
}

float CProjection::FindMaxX()
{
	MY_STACK::iterator Index;
	float Value;
	CPoint2D *Pnt2D;
	Pnt2D = (CPoint2D*) *m_Pnt2DStack.begin();
	Value = Pnt2D->m_X;
	for (Index=m_Pnt2DStack.begin();Index!=m_Pnt2DStack.end();++Index)
	{
		Pnt2D = (CPoint2D*) *Index;
		if ( Pnt2D->m_X > Value )
			Value = Pnt2D->m_X;
	}
	return Value;	
}

float CProjection::FindMinY()
{
	MY_STACK::iterator Index;
	float Value;
	CPoint2D *Pnt2D;
	Pnt2D = (CPoint2D*) *m_Pnt2DStack.begin();
	Value = Pnt2D->m_Y;
	for (Index=m_Pnt2DStack.begin();Index!=m_Pnt2DStack.end();++Index)
	{
		Pnt2D = (CPoint2D*) *Index;
		if ( Pnt2D->m_Y < Value )
			Value = Pnt2D->m_Y;
	}
	return Value;
}

float CProjection::FindMaxY()
{
	MY_STACK::iterator Index;
	float Value;
	CPoint2D *Pnt2D;
	Pnt2D = (CPoint2D*) *m_Pnt2DStack.begin();
	Value = Pnt2D->m_Y;
	for (Index=m_Pnt2DStack.begin();Index!=m_Pnt2DStack.end();++Index)
	{
		Pnt2D = (CPoint2D*) *Index;
		if ( Pnt2D->m_Y > Value )
			Value = Pnt2D->m_Y;
	}
	return Value;
}

void CProjection::SetEmpty()
{
	MY_STACK::iterator Index;
	CPoint2D *pnt2D;
	for (Index=m_Pnt2DStack.begin();Index!=m_Pnt2DStack.end();Index++)
	{
		pnt2D = (CPoint2D*)*Index;
		delete pnt2D;
	}
	m_Pnt2DStack.clear();
	
	CVect2D *v2D;
	for (Index=m_Vect2DStack.begin();Index!=m_Vect2DStack.end();Index++)
	{
		v2D = (CVect2D*)*Index;
		delete v2D;
	}
	m_Vect2DStack.clear();
}

int CProjection::IsIn(CVertex *i_verx)
{
	MY_STACK::iterator Index;
	CVect2D *vect;
	int m_Is=1;
	
	Index=m_Vect2DStack.begin();
	if (Index==m_Vect2DStack.end())
		m_Is=0;
	while (Index!=(m_Vect2DStack.end())&&m_Is)
	{
		vect = (CVect2D*) *Index;
		m_Is=vect->IsIn(i_verx->GetValue(m_AxesX),i_verx->GetValue(m_AxesY));
		Index++;
	}
	if (m_Is)
	{
		return 1;
	}
	else return 0;
}

int CProjection::StoreData(CFile *file)
{
	MY_STACK::iterator Index;

	file->Write("P",1);
	file->Write(&m_AxesX,sizeof(m_AxesX));
	file->Write(&m_AxesY,sizeof(m_AxesY));
	file->Write(&m_Count,sizeof(m_Count));

	CPoint2D *pnt2D;
	for (Index=m_Pnt2DStack.begin();Index!=m_Pnt2DStack.end();Index++)
	{
		pnt2D = (CPoint2D*) *Index;
		pnt2D->StoreData(file);
	}

	CVect2D *vect2D;
	for (Index=m_Vect2DStack.begin();Index!=m_Vect2DStack.end();Index++)
	{
		vect2D = (CVect2D*) *Index;
		vect2D->StoreData(file);
	}
	return 0;
}

void CProjection::ConvertAxes(char Version)
{
	if (Version == 10)
	{
		if (m_AxesX <= 4)
			m_AxesX *= 4;
		else m_AxesX = (m_AxesX - 5)*4 + 2;

		if (m_AxesY <= 4)
			m_AxesY *= 4;
		else m_AxesY = (m_AxesY - 5)*4 + 2;

		Version = 11;
	}
	if (Version == 11)
	{
		if (m_AxesX <= 16)
		{
			int divi = (m_AxesX-1) / 4;
			int rest = (m_AxesX-1) % 4;
			m_AxesX = 4*rest + divi+1;
		}
		if (m_AxesY <= 16)
		{
			int divi = (m_AxesY-1) / 4;
			int rest = (m_AxesY-1) % 4;
			m_AxesY = 4*rest + divi+1;
		}

		Version = 12;
	}
	
	// if new version, here will be if for them

}

int CProjection::LoadData(CFile *file, char Version)
{
	int errorLoad, NumbLoad, Count;
	NumbLoad=file->Read(&m_AxesX,sizeof(m_AxesX));
	if (NumbLoad!=sizeof(m_AxesX))
		return 8;
	NumbLoad=file->Read(&m_AxesY,sizeof(m_AxesY));
	if (NumbLoad!=sizeof(m_AxesY))
		return 8;
	NumbLoad=file->Read(&Count,sizeof(Count));
	if (NumbLoad!=sizeof(Count))
		return 8;

	ConvertAxes(Version);
	
	CPoint2D *pnt2D;
	for (int j=0;j<Count;++j)
	{
		pnt2D = new CPoint2D();
		AddPnt2D(pnt2D);
		errorLoad=pnt2D->LoadData(file);
		if (errorLoad)
			return errorLoad;
	}

	CVect2D *vect2D;
	int k;
	for (k=0;k<Count;++k)
	{
		vect2D = new CVect2D();
		AddVect2D(vect2D);
		errorLoad=vect2D->LoadData(file);
		if (errorLoad)
			return errorLoad;
	}
	return 0;
}

//////////////////////////////////////////////////////////////////////
// CBoundary
void CBoundary::SetEmpty()
{
	MY_STACK::iterator Index;
	CProjection *proj;
	for (Index=m_ProjStack.begin();Index!=m_ProjStack.end();Index++)
	{
		proj = (CProjection*)*Index;
		proj->SetEmpty();
		delete proj;
	}
	m_ProjStack.clear();
	m_Count=0;
}

void CBoundary::AdaptProj(int numb)
{
	MY_STACK::iterator indexProj;
	int pomInd;

	CProjection *Proj;
	indexProj = m_ProjStack.begin();
	while (indexProj != m_ProjStack.end())
	{
		Proj = (CProjection*) *indexProj;
		if (Proj->AdaptAxes(numb))
		{
			pomInd = indexProj - m_ProjStack.begin();
			
			m_ProjStack.erase(indexProj);
			Proj->SetEmpty();
			delete Proj;
			m_Count -= 1;

			indexProj = m_ProjStack.begin() + pomInd;
		}
		else 
		{
			indexProj++;
		}
	}
}

void CBoundary::Draw(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,unsigned char *Clust,int style)
{
	MY_STACK::iterator Index;
	if ( ((*(Clust+m_Numb)) & 2)  !=0  )
	{		
		for (Index=m_ProjStack.begin();Index!=m_ProjStack.end();Index++)
		{
			((CProjection*)*Index)->Draw(pDC,DrawWin,whichValues,whichAxes,m_Numb,style);
		}
	}
}

int CBoundary::FindMinXY(int which, float *Value)
{
	MY_STACK::iterator Index;
	CProjection *MyProj;
	
	for (Index=m_ProjStack.begin(); Index!=m_ProjStack.end(); ++Index)
	{
		MyProj = (CProjection*) *Index;
		if (MyProj->m_AxesX==which)
		{
			*Value = MyProj->FindMinX();
			return 1;
		}
		if (MyProj->m_AxesY==which)
		{
			*Value = MyProj->FindMinY();
			return 1;
		}
	}
	return 0;
}

int CBoundary::FindMaxXY(int which, float *Value)
{
	MY_STACK::iterator Index;
	CProjection *MyProj;
	
	for (Index=m_ProjStack.begin(); Index!=m_ProjStack.end(); ++Index)
	{
		MyProj = (CProjection*) *Index;
		if (MyProj->m_AxesX==which)
		{
			*Value = MyProj->FindMaxX();
			return 1;
		}
		if (MyProj->m_AxesY==which)
		{
			*Value = MyProj->FindMaxY();
			return 1;
		}
	}
	return 0;
}
/*
void CBoundary::Clustering(CVerxStack *i_VerxStack)
{
	MY_STACK::iterator Index;
	MY_STACK::iterator PntsIndex;
	int m_isIn;
	CProjection *m_proj;
	CVertex *m_vx;
	
	for (PntsIndex=i_VerxStack->m_VerxStack.begin();PntsIndex!=i_VerxStack->m_VerxStack.end();PntsIndex++)
	{
		m_isIn=1;
		m_vx = (CVertex*) *PntsIndex;
		
		Index=m_ProjStack.begin();
		if (Index==m_ProjStack.end())
			m_isIn=0;
		while (Index != m_ProjStack.end() && m_isIn)
		{
			m_proj=(CProjection*) *Index;
			m_isIn=m_proj->IsIn(m_vx);
			Index++;
		}

		if (m_isIn)
		{	
			int toStore;
			toStore = m_Numb + 0x10000 * m_Count;
			m_vx->AddClust(toStore);	
//			m_vx->AddClust(m_Numb );
		}
	}
}
*/

bool CBoundary::IsIn(CVertex* Pnt)
{	
	bool bIsIn=true;
		
	MY_STACK::iterator Index=m_ProjStack.begin();

	if (Index==m_ProjStack.end())
		bIsIn=false;

	while ( Index != m_ProjStack.end() && bIsIn)
	{
		CProjection* proj=(CProjection*) *Index;
		bIsIn=proj->IsIn(Pnt);
		Index++;
	}

	return bIsIn;
}

void CBoundary::Clustering(CVertex *Pnt)
{
	MY_STACK::iterator Index;
	int m_isIn;
	CProjection *m_proj;
	
	m_isIn=1;
		
	Index=m_ProjStack.begin();
	if (Index==m_ProjStack.end())
		m_isIn=0;
	while ( Index != m_ProjStack.end() && m_isIn)
	{
		m_proj=(CProjection*) *Index;
		m_isIn=m_proj->IsIn(Pnt);
		Index++;
	}

	if (m_isIn)
	{	
		//Pnt->SetNoise(0);
		int toStore;
		toStore = m_Numb + 0x10000 * m_Count;
		Pnt->AddClust(toStore);	
	}
}


int CBoundary::StoreData(CFile *file)
{
	MY_STACK::iterator Index;

	file->Write("B",1);
	file->Write(&m_Count,sizeof(m_Count));

	CProjection *proj;
	for (Index=m_ProjStack.begin();Index!=m_ProjStack.end();Index++)
	{
		proj = (CProjection*) *Index;
		proj->StoreData(file);
	}
	return 0;
}

int CBoundary::LoadData(CFile *file, char Version)
{
	int NumbLoad,errorLoad=0, Count;

	NumbLoad=file->Read(&Count,sizeof(Count));
	if (NumbLoad!=sizeof(Count))
		return 6;

	if (Count>0)
	{
		char identif;
		CProjection *proj;
		for (int i=1;i<=Count;i++)
		{
			proj = new CProjection(m_PalStack);
			AddProj(proj);
			
			NumbLoad=file->Read(&identif,1);
			if (NumbLoad!=1)
				return 6;

			if (identif=='P')
				errorLoad=proj->LoadData(file, Version);
			else return 7;
			if (errorLoad)
				return errorLoad;
		}
	}
	else m_Count=0;
	return 0;
}

//////////////////////////////////////////////////////////////////////
// CPoint2D
int CPoint2D::StoreData(CFile *file)
{
	file->Write("N",1);
	file->Write(&m_X,sizeof(m_X));
	file->Write(&m_Y,sizeof(m_Y));
	return 0;
}

int CPoint2D::LoadData(CFile *file)
{
	char pom;
	int NumRead;
	NumRead=file->Read(&pom,1);
	if (NumRead!=1)
		return 12;
	if (pom!='N')
		return 13;
	NumRead=file->Read(&m_X,sizeof(m_X));
	if (NumRead!=sizeof(m_X))
		return 12;
	NumRead=file->Read(&m_Y,sizeof(m_Y));
	if (NumRead!=sizeof(m_Y))
		return 12;
	return 0;
}

//////////////////////////////////////////////////////////////////////
// CVect2D
int CVect2D::StoreData(CFile *file)
{
	file->Write("V",1);
	file->Write(&m_X,sizeof(m_X));
	file->Write(&m_Y,sizeof(m_Y));
	file->Write(&m_b,sizeof(m_b));
	return 0;
}

int CVect2D::LoadData(CFile *file)
{
	int NumRead;
	char pom;
	NumRead=file->Read(&pom,1);
	if (NumRead!=1)
		return 10;
	if (pom!='V')
		return 11;
	NumRead=file->Read(&m_X,sizeof(m_X));
	if (NumRead!=sizeof(m_X))
		return 10;
	NumRead=file->Read(&m_Y,sizeof(m_Y));
	if (NumRead!=sizeof(m_Y))
		return 10;
	NumRead=file->Read(&m_b,sizeof(m_b));
	if (NumRead!=sizeof(m_b))
		return 10;
	return 0;
}
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
