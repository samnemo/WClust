// Cluster.h: interface for the CCluster class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CLUSTER_H__41967E0D_1D55_4F3A_B881_CA39A2833FBD__INCLUDED_)
#define AFX_CLUSTER_H__41967E0D_1D55_4F3A_B881_CA39A2833FBD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyObj.h"
#include "Vertex.h"


////////////////////////////////////////////////////////////////////////
// CPoint2D
class CPoint2D : public CMyObject
{
public:
	float m_X,m_Y;
public:	
	CPoint2D(){};
	CPoint2D(float x,float y){ m_X=x;m_Y=y; };
	virtual ~CPoint2D(){};
	int		GetX(){ return m_X; };
	int		GetY(){ return m_Y; };
	void	GetValue(float *X, float *Y){ *X=m_X; *Y=m_Y; }; 
	int		LoadData(CFile *file);
	int		StoreData(CFile *file);
};

////////////////////////////////////////////////////////////////////////
// CVect2D
class CVect2D : public CMyObject
{
protected:
public:
	float m_X,m_Y,m_b;
public:	
	CVect2D(){};
	CVect2D(float x, float y, float b){m_X=x;m_Y=y;m_b=b;};
	virtual ~CVect2D(){};
	int		IsIn(float x,float y){ if(x*m_X+y*m_Y+m_b>=0) return 1; else return 0;};
	int		IsIn(CPoint point){ if(point.x*m_X+point.y*m_Y+m_b>=0) return 1; else return 0;};
	int		LoadData(CFile *file);
	void	Make(float x1, float y1, float x2, float y2){m_X=y1-y2;m_Y=x2-x1;m_b=x1*y2-x2*y1;};
	void	Make(CPoint2D *p1,CPoint2D *p2){m_X=p1->m_Y-p2->m_Y;m_Y=p2->m_X-p1->m_X;m_b=p1->m_X*p2->m_Y-p2->m_X*p1->m_Y;};
	int		StoreData(CFile *file);
};

////////////////////////////////////////////////////////////////////////
// CProjection
class CProjection : public CMyObject
{
public:
	int			m_AxesX,m_AxesY;
	int			m_Count;

	MY_STACK	m_Pnt2DStack;
	MY_STACK	m_Vect2DStack;
protected:
	void	ConvertAxes(char Version);
public:	
	CProjection(){ m_Count=0; };
	CProjection(CPaletteStack *MyPalette){ m_Count=0;m_PalStack=MyPalette; };
	CProjection(int X,int Y){ m_AxesX=X; m_AxesY=Y;m_Count=0; };
	CProjection(int X,int Y,CPaletteStack *MyPalette){ m_AxesX=X; m_AxesY=Y;m_Count=0;m_PalStack=MyPalette; };
	virtual ~CProjection(){ SetEmpty();m_Count=0; };
	void	AddPnt2D(CMyObject *toStore) { m_Pnt2DStack.push_back(toStore); m_Count+=1; };
	void	AddPnt2Dinv(CMyObject *toStore) { m_Pnt2DStack.push_front(toStore); m_Count+=1; };
	void	AddVect2D(CMyObject *toStore) { m_Vect2DStack.push_back(toStore); };
	void	AddVect2Dinv(CMyObject *toStore) { m_Vect2DStack.push_front(toStore); };
	int		AdaptAxes(int numb);
	void	Draw(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,int Color,int style);
	float	FindMinX();
	float	FindMaxX();
	float	FindMinY();
	float	FindMaxY();
	int		IsIn(CVertex *i_verx);
	int		LoadData(CFile *file, char Version);
	void	SetAxes(int X,int Y){ if (X<Y){m_AxesX=X;m_AxesY=Y;}else{m_AxesX=Y;m_AxesY=X;};};
	void	SetEmpty();
	int		StoreData(CFile *file);
};

////////////////////////////////////////////////////////////////////////
// CBoundary
class CBoundary : public CMyObject
{
public:
	MY_STACK	m_ProjStack;
	
	CProjection	undoProj;
	int			undoPosition;

	int			m_Numb;
	int			m_Count;
public:
	CBoundary(){ m_Count=0;m_Numb=0;m_Count=0; };
	CBoundary(CPaletteStack *MyPalette){ m_Count=0;m_Numb=0;m_Count=0;m_PalStack=MyPalette; };
	virtual ~CBoundary(){ SetEmpty(); };
	void	AdaptProj(int numb);
	void	AddProj(CMyObject *toStore) { m_ProjStack.push_back(toStore); m_Count+=1; };
//	void	Clustering(CVerxStack *i_VerxStack);
	void	Clustering(CVertex *Pnt);
	bool    IsIn(CVertex* Pnt);
	void	Draw(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,unsigned char *Clust,int style);
	int		GetNumb(){return m_Numb;}
	int		FindMinXY(int which, float *Value);
	int		FindMaxXY(int which, float *Value);
	int		LoadData(CFile *file, char Version);
	void	RemLastProj() { m_ProjStack.pop_back(); m_Count--; }
	void	SetEmpty();
	int		StoreData(CFile *file);
};

////////////////////////////////////////////////////////////////////////
// CCluster
class CCluster : public CMyObject  
{
public:	
	MY_STACK	m_BndrStack;
	MY_STACK	m_ParamDimStack;
	MY_WCP_FILES_STACK usedExternWCP;
	CBoundary	*undoBndry;
	char		undoType;
	int			m_Count;	//# of clusters?
	char		m_ClMode;  // 0 - random, 1 - exclude, 2 - weighted random
	char		m_Swap;		// 0 - normal, 1 - swapped
	char		m_newChanges;	//  1 - yes, it needs to be saved, 2 - yes, autoSave, 3-both

	int         m_iInfPerClust;         //# of info gain values for each cluster
	vector< vector<double> > m_vInfo[4];   //info gain for each cluster, each cluster has m_iInfPerClust elements
	int m_pNumClusts[4];

	void CalcClusterInfo(CVerxStack& DataStack);
	void GetClusterInfo();
	//"exclusive" info clustering
	void ExclusiveInfoClust(CVerxStack& DataStack,int iClusts);
	//resistor info clustering
	void ResistorInfoClust(CVerxStack& DataStack,int iClusts);
	void KmeansClust(CVerxStack& DataStack,int iClusts);

protected:
	long		dataStartPtr;
public:
	CCluster();
	CCluster(CPaletteStack *MyPalette);
	virtual ~CCluster(){ SetEmpty();m_Count=0; };
	void	AddAxes(CVerxStack *Pnts,CParamDim *param);
	void	AddBndry(CMyObject *toStore) { m_BndrStack.push_back(toStore); m_Count+=1; /*m_newChanges = 3;*/ };
	void	AddParam(CMyObject *toStore, CVerxStack *Pnts);
	void	AutoSave(char *fileAS,CString& strInfo);
	void	CalcParam(CVerxStack *Pnts);
	void	CalcParamLast(CVerxStack *Pnts);
	void	CalcParamOneSpike(CVerxStack *Pnts, CVertex *Pnt, sSpike *spike);
	int		ChooseFileAndStore(CString& strInfo);
	void	Clear();
	void	ClearSwap() { m_Swap = 0; };
	void	ClearUNDO();
	void    SetNoise(CVerxStack *Pnts);
	void	Clustering(CVerxStack *Pnts);
	void	Clustering(CVertex *Pnt);
	void	CreateHeader(FILE *file,CString& strInfo);
	void	Draw(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,unsigned char *Clust,int style);  // 0-bottom is down, 1 bottom is up
	int		FindDataStartPtr( CFile *file );
	void	FindNoise( CVerxStack *pnts );
	void	FindNoise( CVertex *pnt );
	int		GetCount(){ return m_Count; };
	void	GetDataStart();
	char	GetSwap() { return m_Swap; };
	char	GetWantStore() { return m_newChanges; };
	char	IsUNDO(); 
	int		LoadData(CFile *file, CVerxStack *Pnts);
	void	MakeUNDO(int cluster, char type); // type: 0-none, 1-change, 2-insert (after removing)
	int		OpenFile(CFile *file, CVerxStack *Pnts);
	void	RemLastBndry() { m_BndrStack.pop_back(); m_Count--; };
	void	RemParam(CVerxStack*Pnts, int iNum);
	void	RemParamZeros(CVerxStack *Pnts);
	void	SetEmpty();
	void	StoreData(CFile *file);
	void	SwapPolarity(CVerxStack *Pnts);
	void	UNDO();
	void	WantStore() { m_newChanges = 3; };
};

#endif // !defined(AFX_CLUSTER_H__41967E0D_1D55_4F3A_B881_CA39A2833FBD__INCLUDED_)
