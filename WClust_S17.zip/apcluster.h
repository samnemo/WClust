#pragma once

#include <vector>

using namespace std;

void apcluster_main(int argc, char** argv,vector<int>& vIDs);