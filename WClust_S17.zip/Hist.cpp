#include "stdafx.h"
#include "Hist.h"

using namespace std;

Hist::Hist(void)
:m_dMin(0.0),
 m_dMax(0.0),
 m_iBins(0)
{
}

Hist::Hist(double dMin,double dMax,int iBins)
{
	Init(dMin,dMax,iBins);
}

Hist::~Hist(void)
{
}

bool Hist::Init(double dMin,double dMax,int iBins)
{
	if(iBins < 1 || dMin >= dMax)
	{
		return false;
	}

	m_dMin = dMin;
	m_dMax = dMax;
	m_dRange = m_dMax - m_dMin;
	m_iBins = iBins;
	m_dNumElems = 0.0;

	m_counts = vector<int>(iBins);

	return true;
}

bool RandAssign(CVerxStack& DataStack,CCluster& MainClusters,int iClusts,int which)
{
	srand(time(0));
	MY_STACK::iterator Index;	
	for (Index=DataStack.m_VerxStack.begin();Index!=DataStack.m_VerxStack.end();Index++)
	{	
		CVertex* verx = (CVertex*)*Index;

		//skip noise
		if(verx->GetNoise()) continue;

		switch(which)
		{
		case CLUST_KM:
			verx->SetKmeansClust(1+rand()%iClusts);
			break;
		case CLUST_INFO:
			verx->SetInfoClust(1+rand()%iClusts);
			break;
		case CLUST_AP:
			verx->SetInfoClust(1+rand()%iClusts);
			break;
		}
	}
	return true;
}

inline char GetVClust(CVertex* verx,int which)
{
	switch(which)
	{
	case CLUST_USER:
		return verx->GetClust();
		break;
	case CLUST_ORIG:
		return verx->GetOrigClust();
		break;
	case CLUST_KM:
		return verx->GetKmeansClust();
		break;
	case CLUST_INFO:
		return verx->GetInfoClust();
		break;
	case CLUST_AP:
		return verx->GetAPClust();
		break;
	}
	return 0;
}

void FillDistribs(CVerxStack& DataStack,CCluster& MainClusters,int iBins,std::vector< std::vector<Hist> >& vDistribs,int iDistribs,int which)
{
	//distrib for each cluster + 1 for full distrib
	vDistribs = std::vector< std::vector<Hist> >(iDistribs+1);
	int iDims = DataStack.GetDimension() - 1;
	
	int iD=0,iC=1; 
	for(iC=1;iC<=iDistribs;iC++)
	{
		vDistribs[iC] = std::vector<Hist>(iDims);
		for(iD=0;iD<iDims;iD++)
		{	//make sure to do +1 for dimension indices in DataStack
			vDistribs[iC][iD].Init(DataStack.GetMin(iD+1),DataStack.GetMax(iD+1),iBins);
		}
	}
	
	//go through clusters
	//each cluster checks ALL spikes for membership
	//inefficient...but is there a better way without changing the data structures?
	
	MY_STACK::iterator Index;	
	for (Index=DataStack.m_VerxStack.begin();Index!=DataStack.m_VerxStack.end();Index++)
	{	
		CVertex* verx = (CVertex*)*Index;

		//skip noise
		if(verx->GetNoise()) continue;
			
		//go through clusters filling out distrib info
		for(iC=1;iC<=iDistribs;iC++)
		{
			//either spike is in cluster or it is the FULL distribution
			//containing all spikes!!
			if(iC==iDistribs || GetVClust(verx,which)==iC)
			{
				for(iD=0;iD<iDims;iD++)
				{	//+1 since index 0 is # of clusters vertex is in
					vDistribs[iC][iD].IncBinVal(verx->GetValue(iD+1));
				}
			}
		}
	}
}

bool PrintDistribs2(vector< vector< Hist> >& vDistribs, char* fname)
{
	int iClusts = vDistribs.size();

	if(iClusts < 1) return false;

	FILE* fp = fopen(fname,"w");

	if(!fp) return false;

	int iDims = vDistribs[0].size();

	int iC=0,iD=0,iB=0;

	int iBins = vDistribs[iC][iD].NumBins();

	int iMaxCount = 0;
	for(iC=0;iC<iClusts;iC++)
	{
		for(iD=0;iD<iDims;iD++)
		{
			for(iB=0;iB<vDistribs[iC][iD].NumBins();iB++)
			{
				if(vDistribs[iC][iD][iB] > iMaxCount)
				{
					iMaxCount = vDistribs[iC][iD][iB];
				}
			}
		}
	}

	vector< vector<char> > varr((iDims+1) * iBins);

	for(iC=0;iC<varr.size();iC++)
	{
		varr[iC].resize(iMaxCount);
		for(iD=0;iD<iMaxCount;iD++)
		{
			varr[iC][iD]='_';
		}
	}

	for(iC=0;iC<iClusts;iC++)
	{
		for(iD=0;iD<iDims;iD++)
		{
			for(iB=0;iB<iBins;iB++)
			{
				int k;
				for(k=0;k<vDistribs[iC][iD][iB];k++)
				{
					if(varr[iD][iB]=='_')
					{
						varr[iD][iB]=iC;
					}
				}
			}
		}
	}

	for(iD=0;iD<iDims;iD++)
	{
		fprintf(fp,"D%d\n",iD);
		for(iB=0;iB<iBins;iB++)
		{
			int k;
			for(k=0;k<iMaxCount;k++)
			{
				fprintf(fp,"%c",varr[iD][iB]);
			}			
		}
		//fprint
	}

	fclose(fp);

	return true;
}

bool PrintDistribs(vector<vector< Hist> >& vDistribs,char* fname)
{
	int iClusts = vDistribs.size();

	if(iClusts < 1) return false;

	FILE* fp = fopen(fname,"w");
	
	if(!fp) return false;

	int iDims = vDistribs[0].size();

	int iC = 0, iD = 0;

	for(iC=0;iC<iClusts;iC++)
	{
		fprintf(fp,"C%d\n",iC);
		for(iD=0;iD<iDims;iD++)
		{
			fprintf(fp,"D%d\n",iD);
			vDistribs[iC][iD].Print(fp);
		}
		fprintf(fp,"\n");
	}

	fclose(fp);

	return true;
}

int pBins[4] = {10,20,30,40};;

CString GetClusterInfoString(CVerxStack& MainDataStack,CCluster& MainClusters)
{
	CString strInfo,strTmp;

	int k;
	//get cluster I,E info gain for each of # of bins and clusters
	MainClusters.CalcClusterInfo(MainDataStack);

	//create info gain string
	strInfo += "%%BEGIN CLUSTER_INFORMATION_GAIN\n";
	strTmp.Format("// %%InformationGain.0 ( ClusterId %dbinInfoI %dbinInfoI %dbinInfoI %dbinInfoI ",
		pBins[0],pBins[1],pBins[2],pBins[3]);
	strInfo += strTmp;
	strTmp.Format("%dbinInfoE %dbinInfoE %dbinInfoE %dbinInfoE ",
		pBins[0],pBins[1],pBins[2],pBins[3]);
	strInfo += strTmp;
	strTmp.Format("%dbinInfoI/E %dbinInfoI/E %dbinInfoI/E %dbinInfoI/E ",
		pBins[0],pBins[1],pBins[2],pBins[3]);
	strInfo += strTmp;
	strTmp.Format("%dbinInfoUD %dbinInfoUD %dbinInfoUD %dbinInfoUD ",
		pBins[0],pBins[1],pBins[2],pBins[3]);
	strInfo += strTmp;
	strInfo += ")\n";
	unsigned int iC=0;
	int which = CLUST_USER;
	//go through all clusters (last one is FULL distribution so doesn't need to be saved to string)
	for(iC=1;iC<=MainClusters.GetCount() && iC<MainClusters.m_vInfo[which].size();iC++)
	{
		//I , E info gain
		strTmp.Format("%%InformationGain.0 ( %d ",iC);
		strInfo += strTmp;
		for(k=0;k<8;k++)
		{
			strTmp.Format("%.5f ",MainClusters.m_vInfo[which][iC][k]);
			strInfo += strTmp;
		}
		//I / E info gain
		for(k=4;k<8;k++)
		{
			strTmp.Format("%.5f ",MainClusters.m_vInfo[which][iC][k-4]/MainClusters.m_vInfo[which][iC][k]);
			strInfo += strTmp;
		}
		//UD info gain
		for(k=8;k<12;k++)
		{
			strTmp.Format("%.5f ",MainClusters.m_vInfo[which][iC][k]);
			strInfo += strTmp;
		}
		strInfo += " )\n";
	}
	strInfo += "%%END CLUSTER_INFORMATION_GAIN\n\n";
	
	return strInfo;
}

static vector< vector<double> > gvprobs;
void InitProbs(int iMaxNumElems)
{
	gvprobs = vector< vector<double> >(iMaxNumElems+1);
	int i,j;
	gvprobs[0] = vector<double>(1);
	gvprobs[0][0] = 0.0;
	for(i=1;i<=iMaxNumElems;i++)
	{
		gvprobs[i] = vector<double>(i+1);
		for(j=0;j<=i;j++)
		{
			gvprobs[i][j] = (double) j / (double) i;
		}
	}
}
double Prob(int iElems,int i)
{
#ifdef _DEBUG
	if(iElems < gvprobs.size() && i < gvprobs[iElems].size())
#endif
		return gvprobs[iElems][i];
#ifdef _DEBUG
	return (double) i / (double) iElems;
#endif
}

