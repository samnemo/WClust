// $Id: DlgKLDOpt.cpp,v 1.1 2008/03/06 19:44:28 samn Exp $ 
// DlgKLDOpt.cpp : implementation file
//

#include "stdafx.h"
#include "WClust.h"
#include "DlgKLDOpt.h"
#include ".\dlgkldopt.h"


// DlgKLDOpt dialog

IMPLEMENT_DYNAMIC(DlgKLDOpt, CDialog)
DlgKLDOpt::DlgKLDOpt(CWnd* pParent /*=NULL*/)
	: CDialog(DlgKLDOpt::IDD, pParent)
	, m_iNNToFind(5)
	, m_bFast(TRUE)
{
	m_spinBtn.SetRange(1,100);
}

DlgKLDOpt::~DlgKLDOpt()
{
}

void DlgKLDOpt::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SPINNNKLD, m_spinBtn);
	DDX_Text(pDX, IDC_EDITNNKLD, m_iNNToFind);
	DDV_MinMaxInt(pDX, m_iNNToFind, 1, 100);
	DDX_Check(pDX, IDC_CHECK_FAST_KLD, m_bFast);
}


BEGIN_MESSAGE_MAP(DlgKLDOpt, CDialog)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPINNNKLD, OnDeltaposSpinnnkld)
END_MESSAGE_MAP()


// DlgKLDOpt message handlers

void DlgKLDOpt::OnDeltaposSpinnnkld(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: Add your control notification handler code here
	*pResult = 0;
	if(pNMUpDown->iDelta > 0)
		if(m_spinBtn.GetPos()-pNMUpDown->iDelta>=1) 
			pNMUpDown->iDelta *= -1; 
		else 
			pNMUpDown->iDelta=0;
	else if(pNMUpDown->iDelta < 0)
		if(m_spinBtn.GetPos()+pNMUpDown->iDelta<=100)
			pNMUpDown->iDelta *= -1;
		else
			pNMUpDown->iDelta = 0;
}
