// $Id: BatchUtils.h,v 1.5 2009/06/22 03:55:38 samn Exp $ 
#ifndef BATCH_UTILS
#define BATCH_UTILS

#include <string>
#include <vector>

//batch record for processing cluster quality measurement & time-stamp adjustment batches
struct BatchRec
{
	std::string strBPF;        //input .bpf file path
	std::string strCL;         //input .cl file path
	int iTetrode;              //tetrode to load points from
	double dPrct;              //fraction of points to load from bpf
	std::string outCL;         //output .cl file path
	std::string outBPF;
	std::vector<double> vRatings; //cluster ratings -- 0==unknown,1==poor,2==fair,3==good
	                              //                     1.5==poor-fair,2.5==fair-good
	bool bReadyToRun;			//true iff loaded bpf,cl file successfully

	bool bAutoC;				//whether batch is autoclustering
	int iMinClust;				//min # of clusters
	int iMaxClust;				//max # of clusters
	int iDBIters;				//# of iterations to check optimal # of clusters
	int iIters;					//# of iterations of k-means
};

bool ParseQBatchLines(std::vector<std::string>& vstr, std::vector<BatchRec>& vqb);
bool ParseTSBatchLines(std::vector<std::string>& vstr, std::vector<BatchRec>& vb);
bool ParseACBatchLines(std::vector<std::string>& vstr, std::vector<BatchRec>& vb);

#endif
