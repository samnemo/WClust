// DialList.cpp : implementation file
//

#include "stdafx.h"
#include "wclust.h"
#include "DialList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDialList dialog


CDialList::CDialList(CWnd* pParent /*=NULL*/)
	: cdxCSizingDialog(CDialList::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDialList)
	//}}AFX_DATA_INIT
}


void CDialList::DoDataExchange(CDataExchange* pDX)
{
	cdxCSizingDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDialList)
	DDX_Control(pDX, IDCANCEL, m_wndCancel);
	DDX_Control(pDX, IDOK, m_wndOK);
	DDX_Control(pDX, IDC_LIST1, m_wndList);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDialList, cdxCSizingDialog)
	//{{AFX_MSG_MAP(CDialList)
	ON_WM_SHOWWINDOW()
	ON_LBN_SELCHANGE(IDC_LIST1, OnSelchangeList1)
	ON_LBN_DBLCLK(IDC_LIST1, OnDblclkList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDialList message handlers

BOOL CDialList::OnInitDialog() 
{
	cdxCSizingDialog::OnInitDialog();
	
	RestoreWindowPosition(_T("Main\\ListWindow")); 

	AddSzControlEx( m_wndList,exIgnore,exMaximum,exIgnore,exMaximum);
	AddSzControl( m_wndOK,mdRepos,mdNone);
	AddSzControl( m_wndCancel,mdRepos,mdNone);
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDialList::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	cdxCSizingDialog::OnShowWindow(bShow, nStatus);

	MY_STACK::iterator Index,indProj;

	char toWrite[4196];
	
	AxStackX.empty();
	AxStackY.empty();
	ClStack.empty();
	ListNum=0;

	m_MainClusters->CalcClusterInfo(*m_MainDataStack);

	int iC = 1;

	int which = m_MainDataStack->whichDraw;

	if(which == CLUST_USER)
	{	
		if (m_MainClusters->m_BndrStack.begin()+1 != m_MainClusters->m_BndrStack.end())
		{
			for (Index = m_MainClusters->m_BndrStack.begin()+1; Index != m_MainClusters->m_BndrStack.end(); Index++,iC++)
			{
				CBoundary *bndry;
				bndry = (CBoundary*) *Index;

				sprintf(toWrite,"*********************************************************");
				m_wndList.AddString(toWrite);
				AxStackX.push_back(0); 
				AxStackY.push_back(0);
				ClStack.push_back(0);
				ListNum++;
				
				if(bndry->m_bNoise)
					sprintf(toWrite,"NoiseCluster %d",bndry->m_Numb);
				else
					sprintf(toWrite,"Cluster %d",bndry->m_Numb);

				m_wndList.AddString(toWrite);
				AxStackX.push_back(0);
				AxStackY.push_back(0);
				ClStack.push_back(0);
				ListNum++;
				
				sprintf(toWrite,"{");
				m_wndList.AddString(toWrite);
				AxStackX.push_back(0);
				AxStackY.push_back(0);
				ClStack.push_back(0);
				ListNum++;

				for (indProj = bndry->m_ProjStack.begin(); indProj != bndry->m_ProjStack.end(); indProj++)
				{
					CProjection *proj;
					proj = (CProjection*) *indProj;
					
					CString *strT1,*strT2;

					strT1 = m_MainDataStack->GetAxesName(proj->m_AxesX);
					strT2 = m_MainDataStack->GetAxesName(proj->m_AxesY);
					sprintf(toWrite,"   %s, %s",*strT1,*strT2);
					m_wndList.AddString(toWrite);
					AxStackX.push_back(proj->m_AxesX);
					AxStackY.push_back(proj->m_AxesY);
					ClStack.push_back(bndry->m_Numb);
					ListNum++;
				}

				//only write info stats for non-noise clusters
				//info stats of noise clusters are meaningless
				if(!bndry->m_bNoise)
				{
					int k;
					char cTmp[512]={0};
					extern int pBins[4];
					//inclusive kl-div
					sprintf(toWrite,"   ");
					for(k=0;k<4;k++)
					{
						double dInf = m_MainClusters->m_vInfo[which][iC][k];
						sprintf(cTmp,"%dbinI = %.2f     ",pBins[k],dInf);
						strcat(toWrite,cTmp);
					}
					m_wndList.AddString(toWrite);
					AxStackX.push_back(0);
					AxStackY.push_back(0);
					ClStack.push_back(0);
					ListNum++;
					//approximate exclusive kl-div
					sprintf(toWrite,"   ");
					for(k=4;k<8;k++)
					{
						double dInf = m_MainClusters->m_vInfo[which][iC][k];
						sprintf(cTmp,"%dbinE = %.2f     ",pBins[k-4],dInf);
						strcat(toWrite,cTmp);
					}
					m_wndList.AddString(toWrite);
					AxStackX.push_back(0);
					AxStackY.push_back(0);
					ClStack.push_back(0);
					ListNum++;
					//ratio of i_kl_div/e_kl_div
					sprintf(toWrite,"   ");
					for(k=4;k<8;k++)
					{
						double dInf = m_MainClusters->m_vInfo[which][iC][k-4] / m_MainClusters->m_vInfo[which][iC][k];
						sprintf(cTmp,"%dbinI/E = %.2f     ",pBins[k-4],dInf);
						strcat(toWrite,cTmp);
					}
					m_wndList.AddString(toWrite);
					AxStackX.push_back(0);
					AxStackY.push_back(0);
					ClStack.push_back(0);
					ListNum++;

					//uniqueness+distinction "distance"
					sprintf(toWrite,"   ");
					for(k=8;k<12;k++)
					{
						double dInf = m_MainClusters->m_vInfo[which][iC][k];
						sprintf(cTmp,"%dbinUD = %.2f     ",pBins[k-8],dInf);
						strcat(toWrite,cTmp);
					}
					m_wndList.AddString(toWrite);
					AxStackX.push_back(0);
					AxStackY.push_back(0);
					ClStack.push_back(0);
					ListNum++;
				}			
				sprintf(toWrite,"}");
				m_wndList.AddString(toWrite);
				AxStackX.push_back(0);
				AxStackY.push_back(0);
				ClStack.push_back(0);
				ListNum++;
			}
		}
	}
	else
	{
		int iC = 1;
		int iClusts = which == CLUST_ORIG ? m_MainDataStack->m_NumOriginalCl : m_MainClusters->m_pNumClusts[which];
		for (iC = 1; iC <= iClusts; iC++)
		{
			sprintf(toWrite,"*********************************************************");
			m_wndList.AddString(toWrite);
			AxStackX.push_back(0); 
			AxStackY.push_back(0);
			ClStack.push_back(0);
			ListNum++;
			
			sprintf(toWrite,"Cluster %d",iC);
			m_wndList.AddString(toWrite);
			AxStackX.push_back(0);
			AxStackY.push_back(0);
			ClStack.push_back(0);
			ListNum++;
			
			sprintf(toWrite,"{");
			m_wndList.AddString(toWrite);
			AxStackX.push_back(0);
			AxStackY.push_back(0);
			ClStack.push_back(0);
			ListNum++;

			int k;
			char cTmp[512]={0};
			extern int pBins[4];
			//inclusive kl-div
			sprintf(toWrite,"   ");
			for(k=0;k<4;k++)
			{
				double dInf = m_MainClusters->m_vInfo[which][iC][k];
				sprintf(cTmp,"%dbinI = %.2f     ",pBins[k],dInf);
				strcat(toWrite,cTmp);
			}
			m_wndList.AddString(toWrite);
			AxStackX.push_back(0);
			AxStackY.push_back(0);
			ClStack.push_back(0);
			ListNum++;
			//approximate exclusive kl-div
			sprintf(toWrite,"   ");
			for(k=4;k<8;k++)
			{
				double dInf = m_MainClusters->m_vInfo[which][iC][k];
				sprintf(cTmp,"%dbinE = %.2f     ",pBins[k-4],dInf);
				strcat(toWrite,cTmp);
			}
			m_wndList.AddString(toWrite);
			AxStackX.push_back(0);
			AxStackY.push_back(0);
			ClStack.push_back(0);
			ListNum++;
			//ratio of i_kl_div/e_kl_div
			sprintf(toWrite,"   ");
			for(k=4;k<8;k++)
			{
				double dInf = m_MainClusters->m_vInfo[which][iC][k-4] / m_MainClusters->m_vInfo[which][iC][k];
				sprintf(cTmp,"%dbinI/E = %.2f     ",pBins[k-4],dInf);
				strcat(toWrite,cTmp);
			}
			m_wndList.AddString(toWrite);
			AxStackX.push_back(0);
			AxStackY.push_back(0);
			ClStack.push_back(0);
			ListNum++;

			//UD distance
			sprintf(toWrite,"   ");
			for(k=8;k<12;k++)
			{
				double dInf = m_MainClusters->m_vInfo[which][iC][k];
				sprintf(cTmp,"%dbinUD = %.2f     ",pBins[k-8],dInf);
				strcat(toWrite,cTmp);
			}
			m_wndList.AddString(toWrite);
			AxStackX.push_back(0);
			AxStackY.push_back(0);
			ClStack.push_back(0);
			ListNum++;
	
			sprintf(toWrite,"}");
			m_wndList.AddString(toWrite);
			AxStackX.push_back(0);
			AxStackY.push_back(0);
			ClStack.push_back(0);
			ListNum++;
		}
	}
	HICON pom1 = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	CWnd::SetIcon(pom1,true);
}

void CDialList::OnOK() 
{
	StoreWindowPosition(_T("Main\\ListWindow")); 	
	cdxCSizingDialog::OnOK();
}

void CDialList::OnSelchangeList1() 
{
	int i=0;
	while (i<ListNum && !m_wndList.GetSel(i))
	{
		i++;
	}
	AxX = *(AxStackX.begin()+i);
	AxY = *(AxStackY.begin()+i);
	Cl = *(ClStack.begin()+i);

}

void CDialList::OnDblclkList1() 
{
	EndDialog(IDOK);
}
