#pragma once


// ShowXYSpikeDialog dialog

class ShowXYSpikeDialog : public CDialog
{
	DECLARE_DYNAMIC(ShowXYSpikeDialog)

public:
	ShowXYSpikeDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~ShowXYSpikeDialog();

// Dialog Data
	enum { IDD = IDD_DIALOG_SHOW_SPIKE_XY };

	bool GetShowXYSpikes(){ return m_bShowXYSpikes; }

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	//whether to show xy location of spikes for user cluster validation
	bool m_bShowXYSpikes;

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
};
