// ShowXYSpikeDialog.cpp : implementation file
//

#include "stdafx.h"
#include "WClust.h"
#include "ShowXYSpikeDialog.h"
#include ".\showxyspikedialog.h"


// ShowXYSpikeDialog dialog

IMPLEMENT_DYNAMIC(ShowXYSpikeDialog, CDialog)
ShowXYSpikeDialog::ShowXYSpikeDialog(CWnd* pParent /*=NULL*/)
	: CDialog(ShowXYSpikeDialog::IDD, pParent),
	  m_bShowXYSpikes(false)
{	
}

ShowXYSpikeDialog::~ShowXYSpikeDialog()
{
}

void ShowXYSpikeDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(ShowXYSpikeDialog, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()


// ShowXYSpikeDialog message handlers

void ShowXYSpikeDialog::OnBnClickedOk()
{
	CEdit* edit = (CEdit*)GetDlgItem(IDC_EDIT_SHOW_SPIKES_XY);
	edit->SetFocus();
	CString strEdit;
	edit->GetWindowText(strEdit);

	if(!strEdit.CompareNoCase("yes"))
		m_bShowXYSpikes = true;
	else if(!strEdit.CompareNoCase("no"))
		m_bShowXYSpikes = false;
	else
		MessageBox("Invalid input!","WClust - error!",MB_ICONERROR);

	OnOK();
}
