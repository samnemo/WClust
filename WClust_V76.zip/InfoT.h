#ifndef INFOT_H
#define INFOT_H

#include "Hist.h"

//calculates kldiv from p to q using previously computed nearest neighbors
//version with Neighbor** uses less memory since doesn't use many vectors
prob_t FastKLDiv(KDTreeHist& p,KDTreeHist& q,vector<vector< Neighbor > >& vNeighbors,int iClustIDP,vector<int>& vClustIDs);
prob_t FastKLDiv(KDTreeHist& p,KDTreeHist& q,Neighbor** vNeighbors,int iClustIDP,vector<int>& vClustIDs,int iNNToFind);

//calculates kldiv from notp to p using previously computed nearest neighbors
prob_t FastKLDivC(KDTreeHist& p,KDTreeHist& notp,vector<vector< Neighbor > >& vNeighbors,int iClustIDP,vector<int>& vClustIDs);
prob_t FastKLDivC(KDTreeHist& p,KDTreeHist& notp,Neighbor** vNeighbors,int iClustIDP,vector<int>& vClustIDs,int iNNToFind);

//calculates (symmetric) resistor average of kldiv. (kldiv(p,q)*kldiv(q,p))/(kldiv(p,q)+kldiv(q,p))
prob_t FastKLDivSym(KDTreeHist& p,KDTreeHist& q,vector<vector< Neighbor > >& vNeighbors,int iClustIDP,int iClustIDQ,vector<int>& vClustIDs);
prob_t FastKLDivSym(KDTreeHist& p,KDTreeHist& q,Neighbor** vNeighbors,int iClustIDP,int iClustIDQ,vector<int>& vClustIDs,int iNNToFind);

//calculates (symmetric) resistor average of kldiv between p and not p
prob_t FastKLDivSymPNOTP(KDTreeHist& p,KDTreeHist& notp,vector<vector< Neighbor > >& vNeighbors,int iClustIDP,vector<int>& vClustIDs);
prob_t FastKLDivSymPNOTP(KDTreeHist& p,KDTreeHist& notp,Neighbor** pNeighbors,int iClustIDP,vector<int>& vClustIDs,int iNNToFind);

//thread to calculate minimum inter-cluster kldiv for each cluster and add it to Clusters.m_vInfo
bool InterClustKLD(CCluster& Clusters,vector<KDTreeHist>& vDistribs,vector<int>& vClustIDs,int iClusts,bool bFast,vector< vector<Neighbor> >& vnn,int WhichDraw,const CUPDUPDATA* pUp);
bool InterClustKLD(CCluster& Clusters,vector<KDTreeHist>& vDistribs,vector<int>& vClustIDs,int iClusts,bool bFast,Neighbor** vnn,int WhichDraw,const CUPDUPDATA* pUp,int iNNToFind);

//use probability approximations to calculate kldiv of each dimension independently (returns sum over dimensions)
prob_t KLDivApproxExclusiveProb(Hist& p,Hist& q);

//kldiv
prob_t KLDiv(KDTreeHist& p,KDTreeHist& q);
//symmetric kldiv
prob_t KLDivSym(KDTreeHist& p,KDTreeHist& q);
//kldiv
prob_t KLDiv(Hist& p,Hist& q);
//resistor average
prob_t ResistorAvg(prob_t& p,prob_t& q);
//symmetrized form of KL-divergence
prob_t ResistorAvg(Hist& p,Hist& q);

//vZeroes = vector of dimensions that shouldn't contribute to calculations
//vZeroes[i] == 1 , iff you want to exclude dimension i
void CalcUDDist(vector< vector<Hist> >& vDistribs,int iClusts,vector<prob_t>& vcInf,vector< vector<prob_t> >& vcInfInter,vector<int>& vCounts,int iElems,vector<int>& vZeroes,bool bUseCounts);

void CalcRDist(vector< vector<Hist> >& vDistribs,int iClusts,vector<prob_t>& vcInf,vector< vector<prob_t> >& vcInfInter);

void CalcUDDist(vector< KDTreeHist >& vDistribs,vector< KDTreeHist >& vCompDistribs,int iClusts,vector<prob_t>& vcInf,vector< vector<prob_t> >& vcInfInter,vector<int>& vCounts);

//entropy using previously computed nearest neighbors
prob_t Entropy(KDTreeHist& oTree,vector<vector< Neighbor > >& vNeighbors,int iClustID,vector<int>& vClustIDs);

void CalcEXInfo(vector< vector< Hist> >& vDistribs,vector<prob_t>& vcInf,int iClusts,int iDim,vector<int>& vCounts,int iElems);

//vZeroes = vector of dimensions that shouldn't contribute to calculations
//vZeroes[i] == 1 , iff you want to exclude dimension i
template< class T >
void CalcUDDist(vector< TreeHist<T> >& vDistribs,int iClusts,vector<prob_t>& vcInf,vector< vector<prob_t> >& vcInfInter,vector<int>& vCounts,int iElems,vector<int>& vZeroes,bool bUseCounts)
{
	if(vDistribs.size() != iClusts + 2) return;

	vcInf = vector<prob_t>(iClusts+1);

	vcInfInter = vector< vector<prob_t> >(iClusts+1);
	int iC=1;
	for(iC=1;iC<=iClusts;iC++) vcInfInter[iC] = vector<prob_t>(iClusts+1);

	//uniqueness from full distribution for each cluster
	int iC1=1,iC2=1;
	for(iC1=1;iC1<=iClusts;iC1++)
		vcInf[iC1] = KLDiv(vDistribs[iC1],vDistribs[iClusts+1]);

	//inter-cluster distinction measures, KL divergence between
	//a cluster and cluster+other_cluster
	for(iC1=1;iC1<=iClusts;iC1++)
	{
		for(iC2=1;iC2<=iClusts;iC2++)
		{
			if(iC1==iC2)
				vcInfInter[iC1][iC2]=0.0;
			else
			{
				TreeHist<T> oTmp = vDistribs[iC1];
				oTmp.Add(vDistribs[iC2]);
				vcInfInter[iC1][iC2] += KLDiv(vDistribs[iC1],oTmp);
			}				
		}
	}
	//add smallest inter-cluster KL-div
	for(iC1=1;iC1<=iClusts;iC1++)
	{
		prob_t dMinInter = 9e10;
		bool bFound = false;
		if(vCounts[iC1])
		for(iC2=1;iC2<=iClusts;iC2++)
		{
			if(iC1 != iC2 && vCounts[iC2] && vcInfInter[iC1][iC2] < dMinInter)
			{
				dMinInter = vcInfInter[iC1][iC2];
				bFound = true;
			}
		}
		if(bFound)
			vcInf[iC1] += dMinInter;
	}

	if(bUseCounts)
	{
		for(iC1=1;iC1<=iClusts;iC1++)
		{
			vcInf[iC1] = ( (prob_t)vCounts[iC1] / iElems) * vcInf[iC1];
		}
	}
}

template< class T >
prob_t KLDiv(TreeHist<T>& p,TreeHist<T>& q)
{
	prob_t d = 0.0;

	int i = 0;

	prob_t eps = 1e-40;

	typename std::map< vpwrap<T>, int>::iterator PIT = p.Begin();
	for(;PIT!=p.End();PIT++)
	{
		prob_t pp = p.GetITProb(PIT);
		if(pp<=eps) 
			continue;
		
		prob_t qp = q.GetVProb(PIT->first.p_);
		
		if(qp<=eps) 
			continue;
		
		d += pp * ( log2(pp) - log2(qp) );
	}
	return d;
}


#endif