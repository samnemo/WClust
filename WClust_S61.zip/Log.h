// $Id: Log.h,v 1.1 2008/02/02 21:21:11 samn Exp $ 
#ifndef LOG_H
#define LOG_H

bool Write2Log(const char* cstr,...);

#endif
