// $Id: DlgSampBatchF.cpp,v 1.1 2008/02/02 21:26:34 samn Exp $ 
// DlgSampBatchF.cpp : implementation file
//

#include "stdafx.h"
#include "WClust.h"
#include "DlgSampBatchF.h"


// CDlgSampBatchF dialog

IMPLEMENT_DYNAMIC(CDlgSampBatchF, CDialog)
CDlgSampBatchF::CDlgSampBatchF(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSampBatchF::IDD, pParent)
{
}

CDlgSampBatchF::~CDlgSampBatchF()
{
}

void CDlgSampBatchF::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_BATCH_SAMP_TXT, m_EditSampBatchTxt);
}

BOOL CDlgSampBatchF::OnInitDialog(){
	CDialog::OnInitDialog();
	CString str("input_bpf_file TAB input_cl_file TAB prct_of_points_to_load TAB output_cl_file TAB [cluster_1_rating,cluster_2_rating,...]\r\n\r\n");
	str+="C:\\Users\\samn\\test.bpf\tC:\\Users\\samn\\08jan8_test.cl\t0\t1.0\tC:\\Users\\samn\\output\\test.cl\t[1,1,1,1]\r\n\r\n";
	str+="C:\\Users\\samn\\7-25-TTX.bpf\tC:\\Users\\samn\\7-25-TTX-af.cl\t0\t0.2\tC:\\Users\\samn\\qbout\\7-25-TTX-af.cl\t[3,3,3,3]\r\n\r\n";
	str+="C:\\Users\\samn\\b3n_5_es1_t1_c3.bpf\tC:\\Users\\samn\\b3n_5_es1_t1_c3.cl\t0\t0.2\tC:\\Users\\samn\\qbout\\b3n_5_es1_t1_c3.cl\t[1,2,3,1,2,3,1,2,3,1,2,3,1,2,3]\r\n\r\n";
	m_EditSampBatchTxt.SetWindowText(str);	
	return TRUE;
}


BEGIN_MESSAGE_MAP(CDlgSampBatchF, CDialog)
END_MESSAGE_MAP()


// CDlgSampBatchF message handlers
