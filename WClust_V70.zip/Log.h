// $Id: Log.h,v 1.1 2008/02/02 21:21:11 samn Exp $ 
#ifndef LOG_H
#define LOG_H

#include <vector>

using namespace std;

bool Write2Log(const char* cstr,...);
bool WriteVec2Log(vector<float>& v);
bool WriteVec2Log(vector<double>& v);
bool WriteMat2Log(vector<vector<float> >& m);
bool WriteMat2Log(vector<vector<double> >& m);

#endif
