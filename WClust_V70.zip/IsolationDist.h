#ifndef ISOLATION_DIST
#define ISOLATION_DIST

#include <vector>

using namespace std;

float IsolationDist(vector<int>& vClustIDs,int iClustID,vector<float >& vFloat,int iRows,int iCols);

#endif