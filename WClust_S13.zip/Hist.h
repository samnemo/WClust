#pragma once
#include "Cluster.h"

#include <math.h>

//#include <vector>

//static vector< vector<double> > gvprobs;

//inline void InitProbs(ve

double Prob(int,int);

void InitProbs(int iMaxNumElems);

//histogram class, with automatic counting/scaling
//of values to be between min & max
class Hist //: public CMyObject
{
protected:
	
	//counts of values
	std::vector<int> m_counts;

	//vector of probability values, has probs for (0 - m_iNumElems) / m_iNumElems
	std::vector<double> m_probs;
	
	//min value in histogram
	double m_dMin;
	
	//max value in histogram
	double m_dMax;

	//m_dMax - m_dMin
	double m_dRange;
	
	//number of bins
	int m_iBins;

	//# of elements in distribution
	double m_dNumElems;

	//whether need to recalc probabilities
	//(uses lazy evaluation)
	bool m_bNeedReCalc;

public:

	//return bin # for value
	inline int ValIndex(double dVal) const
	{
		//dVal's location in range as # btwn 0 - 1
		double dFctr = (dVal - m_dMin) / m_dRange;
	
		//multiply by # of bins - 1 to have it 0-based index
		return dFctr * (m_iBins - 1);
	}
	
	inline double Max() const { return m_dMax; }
	inline double Min() const { return m_dMin; }
	inline double Range() const { return m_dRange; }
	inline int NumBins() const { return m_iBins; }

	//number of elements in "distribution"
	inline int NumElems() const
	{
		return (int) m_dNumElems;
	}

	//increment bin that dVal is in by 1
	inline bool IncBinVal(double dVal)
	{
		if(dVal < m_dMin || dVal > m_dMax)
		{
			return false;
		}
		m_dNumElems += 1;
		m_bNeedReCalc = true;
		m_counts[ValIndex(dVal)] += 1;	
		return true;
	}

	//decrement bin that dVal is in by 1
	inline bool DecBinVal(double dVal)
	{
		if(dVal < m_dMin || dVal > m_dMax)
		{
			return false;
		}	
		m_dNumElems -= 1;
		m_bNeedReCalc=true;
		m_counts[ValIndex(dVal)] -= 1;	
		return true;
	}
	
	//set bin that dVal is in to iCount
	inline bool SetBinVal(double dVal,int iCount)
	{
		if(dVal < m_dMin || dVal > m_dMax)
		{
			return false;
		}
		int iDx = ValIndex(dVal);
		int iTmp = m_counts[iDx];
		m_dNumElems -= iTmp;
		m_dNumElems += iCount;
		m_counts[iDx] = iCount;
		m_bNeedReCalc = iCount != iTmp;
		return true;
	}
	
	//get count of bin that dVal is in 
	inline int GetBinVal(double dVal) const { return m_counts[ValIndex(dVal)]; }

	//get probability of variable being bin i
	inline double GetBinProb(double dVal) const{ return (double) GetBinVal(dVal) / m_dNumElems; }

	//calc probabilities of 0 - m_dNumElems to help save time
	//only recalculate when the # of elements changes
	//not used
	inline void CalcProbs()
	{
		if(m_bNeedReCalc && m_dNumElems>=1.0)
		{
			m_probs = vector<double>((int)m_dNumElems+1);
			double j;
			for(j=0.0;j<=m_dNumElems;j+=1.0) m_probs[j] = j / m_dNumElems;
			m_bNeedReCalc=false;
		}
	}

	//get probability of bin i
	inline double BinProb(int i)
	{ 
		//CalcProbs();
		//return m_probs[m_counts[i]];
		//return m_counts[i] / m_dNumElems; 
		return Prob(m_dNumElems,m_counts[i]); 
	}
	
	//direct access to bin
	const int& operator[] (int i) const { return m_counts[i]; }
	
	//initialize histogram
	bool Init(double dMin,double dMax,int iBins);

	Hist(void);
	Hist(double dMin,double dMax,int iBins);
	~Hist(void);

	inline void Print(FILE* fp)
	{
		int i;
		for(i=0;i<m_iBins;i++)
		{
			fprintf(fp,"B%d : ",i);
			int j;
			for(j=0;j<m_counts[i];j++)
			{
				fprintf(fp,"*");
			}
			fprintf(fp,"\n");
		}
		fprintf(fp,"\n");
	}
};

//binary logarithm
inline double log2(double d)
{
	static double dl2 = log(2.0);
	return log(d) / dl2;
}

//gets KLDiv using approximate probabilities
//P(j) = (nj+0.5)/(N+0.5jmax)
//n1+n2+...+nmax=N
//the p distribution's counts are first subtracted
//from the q distribution so that the function will
//calculate the "exclusive" information gain
//p is "partial" distribution
//q is "full" distribution
inline double KLDivApproxExclusiveProb(Hist& p,Hist& q)
{
	if(p.NumBins() != q.NumBins()) return -1.0;

	double d = 0.0;

	int i = 0, iBins = p.NumBins();

	double eps = 10e-12;

	double pelems = p.NumElems();
	double qelems = q.NumElems();

	for(i=0;i<iBins;i++)
	{
		double pcount = p[i];
		double qcount = q[i];

		//approximate probability of bin i in distribution p
		double pp = (pcount+0.5) / ( pelems + 0.5*iBins);

		//approximate probability of bin i in distribution q
		//must subtract pcount elements from numerator & denominator of probability
		//approximation so as to maintain "exclusivity" of p distribution
//		double qp = (qcount - pcount + 0.5) / ( qelems - pcount + 0.5*iBins);
		double qp = (qcount - pcount + 0.5) / ( qelems - pelems + 0.5*iBins);

		if(pp<=eps) continue;

		if(qp<=eps) continue;

		d += pp * ( log2(pp) - log2(qp) );
	}

	return d;
}

//returns -1 iff num bins not equal
//otherwise returns KL divergence of histogram/distributions
//this returns "divergence" of distribution q from p
//so q should be a cluster's distribution and p should be full distribution
//make sure when passing in...
//the order matters because it is not symmetric
//however...
//In Bayesian statistics the KL divergence can be used as a measure of the information
//gain in moving from a prior distribution to a posterior distribution. If some new fact
//Y=y is discovered, it can be used to update the probability distribution for X from p(x|I)
//to a new posterior probability distribution p(x|y) using Bayes' theorem
// DKL(p(x|y)||p(x|I)) = sum( p(x|y) * log( p(x|y) / p(x|I) )
//so p can be cluster distribution and q can be full distribution
inline double KLDiv(Hist& p,Hist& q)
{
	if(p.NumBins() != q.NumBins())
	{
		return -1.0;
	}

	double d = 0.0;

	int i = 0 , iBins = p.NumBins();

	double eps = 10e-12;

	for(i=0;i<iBins;i++)
	{
		double pp = p.BinProb(i); //probability of bin i in distribution p
		if(pp<=eps) continue;
		double qp = q.BinProb(i); //probability of bin i in distribution q
		if(qp<=eps) continue;
		d += pp * ( log2(pp) - log2(qp) );
	}

	return d;
}

//symmetrized form of KL-divergence
inline double ResistorAvg(Hist& p,Hist& q)
{
	double d12 = KLDiv(p,q), d21 = KLDiv(q,p);
	return (d12 * d21) / (d12 + d21);
}

//calculates information gain as resistor average of all clusters against full distribution
//plus smallest resistor average between cluster and all other clusters
//vDistribs must have size of iClusts + 1
inline void CalcRDist(vector< vector<Hist> >& vDistribs,int iClusts,vector<double>& vcInf,vector< vector<double> >& vcInfInter)
{
	if(vDistribs.size() != iClusts + 1) return;

	vcInf = vector<double>(iClusts);

	vcInfInter = vector< vector<double> >(iClusts);
	int iC=0;
	for(iC=0;iC<iClusts;iC++) vcInfInter[iC] = vector<double>(iClusts);

	int iDims = vDistribs[0].size() , iD = 0;

	//only need this for first time, since its recalculated for distributions who's
	//points change, when they change
	int iC1=0,iC2=0;
	for(iC1=0;iC1<iClusts;iC1++)
	{
		double kldiv=0.0;
		for(iD=0;iD<iDims;iD++)
		{
			kldiv += ResistorAvg(vDistribs[iC1][iD],vDistribs[iClusts][iD]);
		}
		vcInf[iC1]=kldiv;
	}

	//fill inter-cluster resistor averages
	for(iC1=0;iC1<iClusts;iC1++)
	{
		for(iC2=0;iC2<=iC1;iC2++)
		{
			if(iC1==iC2)
				vcInfInter[iC1][iC2]=0.0;
			else
			{
				for(iD=0;iD<iDims;iD++)
				{
					vcInfInter[iC1][iC2]+=ResistorAvg(vDistribs[iC1][iD],vDistribs[iC2][iD]);
				}
				vcInfInter[iC2][iC1]=vcInfInter[iC1][iC2];
			}				
		}
	}
	//add largest inter-cluster resistor average
	for(iC1=0;iC1<iClusts;iC1++)
	{
		double dMinInter = 9e20;
		for(iC2=0;iC2<iClusts;iC2++)
		{
			if(iC1 != iC2 && vcInfInter[iC1][iC2] < dMinInter)
			{
				dMinInter = vcInfInter[iC1][iC2];
			}
		}
		vcInf[iC1] += dMinInter;
	}
}

inline double FullProb(Hist& h)
{
	double p = 0.0;
	for(int i=0;i<h.NumBins();i++)
	{
		p += h.BinProb(i);
	}
	return p;
}

template< class T > 
T Sum(vector<T>& v)
{
	int i;
	T val = T(0);
	for(i=0;i<v.size();i++) val += v[i];
	return val;
}

//get vector containing information gain for each cluster
//std::vector<double> GetClusterInfo(CVerxStack& DataStack,CCluster& MainClusters,CPaletteStack* pMainPal,CFile* pFileBPF,int iBins,int iClusts,int which);
//get string rep of cluster info gain for writing to bpf,cl files
CString GetClusterInfoString(CVerxStack& MainDataStack,CCluster& MainClusters,CPaletteStack* pMainPal);

bool PrintDistribs(vector<vector< Hist> >& vDistribs,char* fname);

void FillDistribs(CVerxStack& DataStack,CCluster& MainClusters,CPaletteStack* pMainPal,CFile* pFileBPF,int iBins,std::vector< std::vector<Hist> >& vDistribs,int iClusts,int which);

bool RandAssign(CVerxStack& DataStack,CCluster& MainClusters,int iClusts,CFile* pBPF,int which);
