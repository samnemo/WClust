// Vertex.h: interface for the CVertex class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VERTEX_H__80EE18DE_3F8F_4FBA_8BA5_36D095AD0655__INCLUDED_)
#define AFX_VERTEX_H__80EE18DE_3F8F_4FBA_8BA5_36D095AD0655__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyObj.h"
#include "SyncStack.h"
#include "EEGStack.h"
#include <deque>

using namespace std;

#define		FILE_BPF		1;
#define		FILE_UFF		2;

#define     CLUST_USER      0
#define     CLUST_ORIG      1
#define     CLUST_KM        2
#define     CLUST_INFO      3


////////////////////////////////////////////////////////////////////////
// BPF struct
struct sBPF {
	int		NumberOfEegChannels;

	int		EEG_SIZE;
	int		SINGLE_SIZE;
	int		STEREO_SIZE;
	int		TETRODE_SIZE;
	int		SYNC_SIZE;
	int		ROOM_POSITION_SIZE;                      
	int		ARENA_POSITION_SIZE;
	int		KEY_EVENT_SIZE;

	// Identifiers
	char	ARENA_POSITION_TYPE;
	char	ROOM_POSITION_TYPE;
	char	EEG_TYPE;
	char	SINGLE_TYPE;
	char	STEREO_TYPE;
	char	TETRODE_TYPE;
	char	SYNC_TYPE;
	int		KEY_EVENT_TYPE;
};

////////////////////////////////////////////////////////////////////////
// Spikes parameters

#define		SPIKE_ON_DISK	0;
#define		SPIKE_IN_MEMORY	1;

struct sSpike {
	char	type;		// 0-spike is on disk, 1-spike is in memory (offset is order in stack)	
	unsigned char	cluster;
	char	origCluster;
	int		TimeStamp;
	int		offset;		// offset in file. If file is in memory than offset contains offset in m_VerxStack
	VERTEX	fileParams;	// parameters from file WCP
};

typedef deque <sSpike*> MY_SPIKE_STACK;

////////////////////////////////////////////////////////////////////////
// Definition for load portrait of BPF/UFF file.
// It is for faster loading of parameters

struct sSpikeInFile {
	unsigned char	electrode;	// 1-singlode, 2-stereode, 4-tetrode
	unsigned char	channel;
};

typedef deque <sSpikeInFile*> MY_FILE_PORTRAIT_STACK;

////////////////////////////////////////////////////////////////////////
struct sNoiseParams {
	char spikeMode; // 0-max first, 1-min first
	unsigned char timeMin;
	unsigned char timeMax;
};

////////////////////////////////////////////////////////////////////////
// sWcpFiles
struct sWcpFiles 
{
	int flag;	// 0 - bad file, 1 - OK, >127 - important
	CString fileName;
	CString paramName;	// is defined in the fileName file
};

typedef deque <sWcpFiles> MY_WCP_FILES_STACK;


////////////////////////////////////////////////////////////////////////
// CParamDim
class CParamDim : public CMyObject
{
public:
	int m_Type;
	float m_Par1, m_Par2, m_Par3, m_Par4;
	CParamDim(){};
	CParamDim(int type, float par1){ m_Type = type; m_Par1 = par1; };
	CParamDim(int type, float par1, float par2){ m_Type = type; m_Par1 = par1; m_Par2 = par2; };
	CParamDim(int type, float par1, float par2, float par3){ m_Type = type; m_Par1 = par1; m_Par2 = par2; m_Par3 = par3;};
	CParamDim(int type, float par1, float par2, float par3, float par4){ m_Type = type; m_Par1 = par1; m_Par2 = par2; m_Par3 = par3; m_Par4 = par4; };
	int		GetType(){ return m_Type; };
	float	GetParam(int num){ if (num==1) return m_Par1;if (num==2) return m_Par2;if (num==3) return m_Par3;if (num==4) return m_Par4;return 0;};
	void	SetParam(int index, float param);
	~CParamDim(){};
};


////////////////////////////////////////////////////////////////////////
// CVertex
class CVertex : public CMyObject  
{
protected:
	VERTEX	m_Vertex;		// Main values of vector
	int		m_Flag;			// bit: 0-draw it, 1-YValues and d2Y is allocated, 2-draw spike, 7-noise
	int		m_TimeStamp;
	int		*m_MyClusts;	// Stack of clusters in which this vector is
	float	*m_YValues;
	float	*m_d2YValues;
	char	m_OrigClust;
	char    m_KmeansClust;
	char    m_InfoClust;
	unsigned char	timeMin;	// resolution 10 us, i.e. max 2.55 ms 
	unsigned char	timeMax;	// dtto
	static sNoiseParams noiseParams;
public:
	CVertex(CPaletteStack *MyPalette){m_PalStack=MyPalette; m_Flag=1; m_KmeansClust=0; m_InfoClust=0; m_OrigClust=0;};
	virtual ~CVertex(){ EmptyClust(); if (m_Flag&0x0002) {free(m_YValues);free(m_d2YValues);} };
	void	AddClust(int toStore);
	void	AddPnt(float toStore);
	void	CalcAvgSpike(float *xa, int Freq, int Samples, CRect DrawWin, int whichChanel, int whichClust, float *Average,int *Numb, int whichDraw);
	void	CalcParam(CParamDim *param,float *xa,int Freq,int Samples, sSpike *spike);
	void	CheckNoise();
	void	ClearHighDim(int Dim);
	void    DoDraw(CDC* pDC,CRect DrawWin, CFloatRect* whichValues,CPoint whichAxes,int PntSize,unsigned long color);
	void	Draw(CDC *pDC, CRect DrawWin, CFloatRect *whichValues, CPoint whichAxes, unsigned char *Clust, int PntSize);
	void	DrawOrig(CDC *pDC, CRect DrawWin, CFloatRect *whichValues, CPoint whichAxes, unsigned char *Clust, int PntSize);
	void	DrawAutoC(CDC *pDC, CRect DrawWin, CFloatRect *whichValues, CPoint whichAxes, unsigned char *Clust, int PntSize,char whichAuto);
	void	DrawTimeSpikes(CDC *pDC, float *xa, int freq, int samples, CRect spikeWin, CRect drawWin, int whichChanel, int whichSpDraw);
	void	DrawSpikes(CDC *pDC, float *xa, int Freq, int Samples, CRect DrawWin, int whichChanel, int whichClust, int whichDrawMode);
	int		DrawSpikes(CDC *pDC, float *xa, int Freq, int Samples, CRect DrawWin, int whichChanel);
	void	EmptyClust(){ if (*m_Vertex.begin()!=0) {free(m_MyClusts); SetValue(0,0);}; };
	void	ExportValues( FILE *file, int* pOverRideClust=0 );
	int		GetClust(int mIndex){ return *(m_MyClusts+mIndex); };
	int		GetClust();
	int		GetFlag() { return m_Flag; };
	char	GetNoise() { if ((m_Flag & 0x80 ) || m_OrigClust<0) return 1; else return 0; }; // 0-signal, 1-noise
	char	GetOrigClust() { return m_OrigClust; };
	char    GetKmeansClust() { return m_KmeansClust; };
	void    SetKmeansClust(char c) { m_KmeansClust = c; }
	char    GetInfoClust() { return m_InfoClust; };
	void    SetInfoClust(char c) { m_InfoClust = c; };
	int		GetTimeStamp() { return m_TimeStamp; };
	//gets number of dims in this vector, remember that dim 0 is the # of clusters this vector belongs to
	int		GetNumDims() { return m_Vertex.size(); };
	float	GetValue(int mIndex,MY_STACK::iterator whichVerx);
	float	GetValue(int mIndex){ return *(m_Vertex.begin()+mIndex);};
	float	GetYValues(int mIndex);
	double  GetEnergy(int iSamples,int iChannel);
	int		IsInCluster(int num);
	void	RemHighDim(int num);
	void	SelectCluster(int modeCl);
	void	SetFlag(int Value) { m_Flag = Value; };
	void	SetDraw(int Num) { if (Num) SetFlag(GetFlag()|0x0001);else SetFlag(GetFlag()&0xFFFE); };
	void	SetDrawSpike(int Num) { if (Num) SetFlag(GetFlag()|0x0004);else SetFlag(GetFlag()&0xFFFB); };
	void	SetTimeMin(char timeMin_10us) { timeMin = timeMin_10us; };
	void	SetTimeMax(char timeMax_10us) { timeMax = timeMax_10us; };
	void	SetNoise(char on_off);// { if (on_off != 0) m_Flag |= 0x80; else m_Flag &= 0xFFFFFF7F; };
	void	SetOrigCl(char OCl){ m_OrigClust = OCl;};
	void	SetTimeStamp(int TS) { m_TimeStamp = TS; };
	void	SetYValues(float *mNew, float *x, float *u, int channels, int samples);
	void	SetValue(int mIndex,float Value){ *(m_Vertex.begin()+mIndex)=Value; };
	void	Spline(float *x,float *y,int n,float *d2y,float *u);
	void	Spline(float *x,int n,float *u);
	float	Splope(float *xa,float *ya,float *d2y,float x,int lo_pt,int hi_pt);
	float	Splope(float *xa,float x,int lo_pt,int hi_pt);
	float	Splope(float *xa,float x,int lo_pt,int hi_pt,int channel,int Samples);
	float	Splint(float *xa,float *ya,float *d2y,float x,int lo_pt,int hi_pt);
	float	Splint(float *xa,float x,int lo_pt,int hi_pt);
	float	Splint(float *xa,float x,int lo_pt,int hi_pt,int channel,int Samples);
	void	Swap(int channels, int samples); // Swap +/- polarity of spikes

	friend class CCluster;
};


////////////////////////////////////////////////////////////////////////
// CVerxStack
class CVerxStack : public CMyObject
{
public:
	// stacks
	MY_STACK		m_VerxStack;	// main vectors of spikes
	MY_SPIKE_STACK	m_SpikesStack;	// data of used channel (extern. params, file pos. etc.)
	MY_FILE_PORTRAIT_STACK filePortraitStack;	// image of file
	MY_STR_STACK	m_AxesStack;	// axes' names
	CSyncStack		m_MainSyncStack;// sync signal
	CEEGStack		m_MainEEGStack;	// eeg signal
	MY_WCP_FILES_STACK wcpFilesStack;	// found external parameters files
	
	// constants
	int				SAMPLE_FREQ;		// Frequency of electrode signal
	int				EEG_SAMPLE_FREQ;	// Frequency of eeg signal
	int				NUM_CHANNELS;
	int				NUM_SAMPLES;
	char			BASE_DIMENSION;
	int				RESOLUTION;
	
	int				AreData;
	int				Dimension;
	int				whichDraw;			//original clustering = 1 or new clustering = 0
	char			InBpfExist;			//0 - nothing, 1 - arena, 2 - room, 3 - both
	char			LoadedAdd;			//0 - nothing, 1 - arena, 2 - room, 3 - both
	char			FileType;			//0 - none, 1 - BPF, 2 -UFF
	int				AmountDataFromFile;	

	float			*m_x;
	char			*m_FileName;
	char			*m_TmpName;			
	CString			m_FileNameWithoutExt;	//this is a CString, you can add ext
	int				m_NumVerx;		// in memory
	int				m_NumVerxAll;	// in file (actual channel)
	int				m_NumOriginalCl;
	char			m_ElectrodeChannel;
	char			m_ElectrodeType;	//1 - single, 2 - stereo, 3 - tetrode
	VERTEX			m_MainMin,m_MainMax; // without noise
	VERTEX			m_MainNoisedMin,m_MainNoisedMax;

protected:
	short			*forStoreBPF_buffer;
	float			*forStoreBPF_u;
	CFile			forStoreBPF_file;
	long			forStoreBPF_IndexFile;
	MY_STACK::iterator forStoreBPF_IndexVx;
	int				forStoreBPF_ArenaIndex;
	int				forStoreBPF_RoomIndex;
	int				forStoreBPF_SpikeIndex;
	
	CString			wcpFileNameMask;
	CString			wcpPath;
	sBPF			bpf;

	char			dFileOK;		// is <>0 if BPF is OK
	char			dLastType;		// last type of record in BPF
	long			dLastPos;		// position of last record;
	long			dFileLength;	// length of BPF;
	
	bool			m_FakeSpikes;	// true, if fake spikes are used

public:
	CVertex			*forStoreBPF_NonClVx;	// vertex which isn't in memory
	sSpike			*forStoreBPF_Spike;

	//defaults to draw mode for lookup, otherwise
	//may be specified by user
	inline char GetVClust(CVertex* verx,int which=-1)
	{
		int iWhich = which;
		if(iWhich == -1) iWhich = this->whichDraw;
		switch(iWhich)
		{
		case CLUST_USER:
			return verx->GetClust();
		case CLUST_ORIG:
			return verx->GetOrigClust();
		case CLUST_KM:
			return verx->GetKmeansClust()+1;
		case CLUST_INFO:
			return verx->GetInfoClust()+1;
		}
		return 0;
	}

	//idx is index, look up vertex cluster, assuming it is in memory
	inline char LookupVClust(int idx,int which=-1)
	{
		CVertex* verx;
		MY_SPIKE_STACK::iterator indexSp;
		int iV = 0;
		for(indexSp=m_SpikesStack.begin();indexSp!=m_SpikesStack.end();indexSp++,iV++)
		{
			if(iV==idx)
			{
				if((*indexSp)->type == 1)
				{	// spike is in memory
					verx = (CVertex*)*(m_VerxStack.begin() + (*indexSp)->offset);
#ifdef _DEBUG
					char c = GetVClust(verx,which);
					if(c==0)
					{
						int m=0;
					}
#endif

					if(verx->GetNoise()) 
						return -1;

					return GetVClust(verx,which);
				}
			}
		}
		return 0;
	}

// Methods
protected:
	void	CalcAfterLoad();
	long	GetBPFDataPtr(CFile *file);
	int		GetBPFHeader(char *buffer, int nRead, char *errChar);
	int		GetBPFHeader_SetupInformation(char *buffer, int nRead, char *errChar);
	int		LoadBPF(CFile *file, char *buffer, int nRead, char *errChar, long *errOffset);
	int		LoadUFF(CFile *file, char *buffer, int nRead);
	int		StoreUFF(CFile *file);
	
	void	AddFakeSpike( int TimeStamp );
public:	
	CVerxStack();
	CVerxStack(CPaletteStack *MyPalette){ m_PalStack=MyPalette; RESOLUTION = 16; whichDraw = 1;};
	~CVerxStack(){ SetEmpty();free(m_x); };
	void	AddVrx(CMyObject *toStore);
	void	AddAxes(CString *toStore){ m_AxesStack.push_back(toStore); };
	void	CalcMinMax();
	void	CalcMinMaxLast();
	void	CalcOneSpike(CVertex *verx);
	void    AddVertexTimeStamps();
	void    DoVertexPCA(); //pca
	void	CalcViewVx(int FirstEv,int LastEv,int PercEv);
	void	CalcViewSpike(int FirstEv,int LastEv,int PercEv);
	void	CalcViewSpike(int FirstEv,int LastEv,int PercEv,int Clust);
	void	CalcViewSpike(int FirstEv,int LastEv,int PercEv, unsigned char *clView, char numb);
	void	CheckNoise();
	void	CheckWcpFiles();
	void	ClearExternalParamData();
	void	ClearHighDim();
	void	CreateHeaderForExport(FILE *file,CString& oStrExtra);//oStrExtra has optional extra header information
	void	Draw(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,unsigned char *Clust); 
	void	Draw(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,unsigned char *Clust,int PntSize); 
	void	DrawOrig(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,unsigned char *Clust); 
	void	DrawOrig(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,unsigned char *Clust,int PntSize); 
	void	DrawAutoC(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,unsigned char *Clust,char whichAutoC); 
	void	DrawAutoC(CDC *pDC,CRect DrawWin,CFloatRect *whichValues,CPoint whichAxes,unsigned char *Clust,int PntSize,char whichAutoC); 
	void	DrawTimeSpikes(CDC *pDC, CRect drawWin, int startTime, int timeWindow, int TSFirst, char params, unsigned char *clView, CFile *file);
	void	DrawSpikes(CDC *pDC,CRect DrawWin,int whichChanel,int whichClust);
	void	DrawSpikes(CDC *pDC,CRect DrawWin,int whichChanel,int Start,int Stop);
	int		DrawSpikes(CDC *pDC,CRect DrawWin,int whichChanel,int Start,int HowMany,int *Last);
	void	FinishStoreBPF();
	int		GetBaseDimension(){ return BASE_DIMENSION; };
	int		GetClust(int NoOfVerx);
	char	GetDFileOK() { return dFileOK; };		// for repair BPF
	char	GedDLastType() { return dLastType; };	// for repair BPF
	long	GetDLastPos() { return dLastPos; };		// for repair BPF
	long	GetDFileLength() { return dFileLength; };// for repair BPF
	int		GetDimension(){ return Dimension; };
	bool	GetFakeSpikes() { return m_FakeSpikes; };
	char	GetFileType(){ return FileType; };
	int		GetNumVerx(){ return m_NumVerx; };
	float	GetMin(int Index);
	float	GetMax(int Index);
	CString* GetAxesName(int mIndex){ if (mIndex>0 && mIndex<=Dimension) return *(m_AxesStack.begin()+mIndex-1);else return *(m_AxesStack.begin()); };
	int		IsEmpty(){ if (AreData) return 0; else return 1; };
	int		LoadBPFElde(CVertex *pnt, CFile *file, int offset);
	int		LoadVerx( char *errChar, long *errOffset);
	void	PasteFileParamAsZeros( );
	void	PasteFileParameter( sWcpFiles *paramToAdd );
	int		PrepareStoreBPF();
	void	RemoveExternalParam(int iNum);
	int		StoreBPFElde();
	int		StoreBPF(char *State);
	int		StoreBPFAddition();
	int		StoreClMarks();
	void	SetEmpty();
	void	SetPalette(CPaletteStack *pal);
	void	SwapPolarity(); // Swap +/- polarity of spikes

	friend class CCluster;
};


#endif // !defined(AFX_VERTEX_H__80EE18DE_3F8F_4FBA_8BA5_36D095AD0655__INCLUDED_)
