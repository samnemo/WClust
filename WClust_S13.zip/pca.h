/*********************************/
/* Principal Components Analysis */
/*********************************/

#include <vector>

using namespace std;

//typedef vector< vector<double> > d2d;

/**  Correlation matrix: creation  ***********************************/
void corcol(vector< vector<double> >& data,int n,int m,vector< vector<double> >& symmat);
/**  Variance-covariance matrix: creation  *****************************/
void covcol(vector< vector<double> >&  data,int n,int m,vector< vector<double> >& symmat);
/**  Sums-of-squares-and-cross-products matrix: creation  **************/
void scpcol(vector< vector<double> >& data,int n,int m,vector< vector<double> >& symmat);
/**  Error handler  **************************************************/
void erhand(char* err_msg);
/**  Allocation of vector storage  ***********************************/
double *p_vector(int n);
/**  Allocation of double matrix storage  *****************************/
double **p_matrix(int n,int m);
/**  Deallocate vector storage  *********************************/
void free_p_vector(double* v,int n);
/**  Deallocate double matrix storage  ***************************/
void free_p_matrix(double** mat,int n,int m);
/**  Reduce a real, symmetric matrix to a symmetric, tridiag. matrix. */
void tred2(vector< vector<double> >& a,int n,vector<double>& d,vector<double>& e);
/**  Tridiagonal QL algorithm -- Implicit  **********************/
void tqli(vector<double>& d,vector<double>& e,int n,vector< vector<double> >& z);

