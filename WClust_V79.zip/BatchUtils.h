// $Id: BatchUtils.h,v 1.3 2008/04/10 03:44:04 samn Exp $ 
#ifndef BATCH_UTILS
#define BATCH_UTILS

#include <string>
#include <vector>

//batch record for processing cluster quality measurement batches
struct QBatchRec
{
	std::string strBPF;        //input .bpf file path
	std::string strCL;         //input .cl file path
	int iTetrode;              //tetrode to load points from
	double dPrct;              //fraction of points to load from bpf
	std::string outCL;         //output .cl file path
	std::vector<double> vRatings; //cluster ratings -- 0==unknown,1==poor,2==fair,3==good
	                              //                     1.5==poor-fair,2.5==fair-good
	bool bReadyToRun;			//true iff loaded bpf,cl file successfully
};

bool ParseQBatchLines(std::vector<std::string>& vstr, std::vector<QBatchRec>& vqb);

#endif
