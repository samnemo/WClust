#ifndef STRING_UTILS_H
#define STRING_UTILS_H

#include <string>
#include <vector>

//remove newlines from end of str
bool Chop(char* str);

//split string based on chars in strDelim and return tokens in vstr
void Split(std::string& str,std::string& strDelim,std::vector<std::string>& vstr);

#endif