#pragma once

#include <windows.h>
#include <string>

struct ScopedTimer
{
	DWORD S,E;
	std::string msg;

	ScopedTimer(char* c)
	{
		if(c) msg = c;
		S = GetTickCount();
	}

	~ScopedTimer()
	{
		E = GetTickCount();
		
		char msg2[1024];
		
		if(msg.length())
			sprintf(msg2,"%s time = %d",msg.c_str(),E-S);
		else
			sprintf(msg2,"time = %d",E-S);
		
		MessageBox(0,msg2,"WClust",MB_ICONINFORMATION);
	}
};