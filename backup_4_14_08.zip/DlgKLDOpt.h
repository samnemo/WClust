// $Id: DlgKLDOpt.h,v 1.3 2008/03/19 15:11:30 samn Exp $ 
#pragma once
#include "afxcmn.h"


// DlgKLDOpt dialog

class DlgKLDOpt : public CDialog
{
	DECLARE_DYNAMIC(DlgKLDOpt)

public:
	DlgKLDOpt(CWnd* pParent = NULL);   // standard constructor
	virtual ~DlgKLDOpt();

// Dialog Data
	enum { IDD = IDD_DIALOG_KLD_DLG_OPT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	int m_iNNToFind;
	BOOL m_bFast;
	BOOL m_bInterKLD;
	BOOL m_bIsolationDist;
	BOOL m_bDoKLDiv;
};
