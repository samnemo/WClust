// $Id: DlgKLDOpt.cpp,v 1.3 2008/03/19 15:12:05 samn Exp $ 
// DlgKLDOpt.cpp : implementation file
//

#include "stdafx.h"
#include "WClust.h"
#include "DlgKLDOpt.h"
#include ".\dlgkldopt.h"


// DlgKLDOpt dialog

IMPLEMENT_DYNAMIC(DlgKLDOpt, CDialog)
DlgKLDOpt::DlgKLDOpt(CWnd* pParent /*=NULL*/)
	: CDialog(DlgKLDOpt::IDD, pParent)
	, m_iNNToFind(1)
	, m_bFast(TRUE)
	, m_bInterKLD(TRUE)
	, m_bIsolationDist(FALSE)
	, m_bDoKLDiv(TRUE)
{
}

DlgKLDOpt::~DlgKLDOpt()
{
}

void DlgKLDOpt::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Check(pDX, IDC_CHECK_FAST_KLD, m_bFast);
	DDX_Check(pDX, IDC_CHECK_INTER_KLD, m_bInterKLD);
	DDX_Check(pDX, IDC_CHECK_ISOLATION_D, m_bIsolationDist);
	DDX_Check(pDX, IDC_CHECK_KLD_DO, m_bDoKLDiv);
}


BEGIN_MESSAGE_MAP(DlgKLDOpt, CDialog)
END_MESSAGE_MAP()


// DlgKLDOpt message handlers

