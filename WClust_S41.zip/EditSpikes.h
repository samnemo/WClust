#if !defined(AFX_EDITSPIKES_H__AD5F9CE0_9E13_11D6_9179_9DFBF872187C__INCLUDED_)
#define AFX_EDITSPIKES_H__AD5F9CE0_9E13_11D6_9179_9DFBF872187C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditSpikes.h : header file
//
#include "cdxCSizingDialog.h"
#include "MyObj.h"
#include "Vertex.h"
#include "Cluster.h"
#include "ColorComboBox.h"

/////////////////////////////////////////////////////////////////////////////
// CEditSpikes dialog

class CEditSpikes : public cdxCSizingDialog
{
public:
	CVerxStack *m_MainDataStack;
	CPaletteStack *m_MainPalette;
	CCluster *m_MainClusters;
	
	CRect m_MainRect,m_DrawingRect;
	CRect m_sizeLeft,m_sizeRight,m_ClearRect;
	
	int m_FirstEdSp,m_LastEdSp,m_PercEdSp;	// spikes in the editation mode
	int m_size;
	int m_ActualEdSp,m_RestoreAct,m_LoadAct;
	int m_DrawOnlyOne, m_IsEnd, m_IsPlay, m_IsStopped;
	int m_DrawingMode;
	int m_MovingMode;
	int m_IsLine1, m_IsLine2;
	float m_Line1Pos, m_Line2Pos;

	HCURSOR m_HCross,m_HSize;
protected:
	CImageList		m_imageList;
	vector<unsigned char>	clView;
	char			maxCluster;
	unsigned char	CLUST_SEL;

protected:
	MY_STACK m_paramStack;
	void EnableButton();
	void DisableButton();
	void FillCmbProp();
	void FillImageList();
	void FillClList();
	void CalcWhatShow();

// Construction
public:
	CEditSpikes(CWnd* pParent = NULL);   // standard constructor
// Dialog Data
	//{{AFX_DATA(CEditSpikes)
	enum { IDD = IDD_EDIT_SPIKES };
	CListCtrl	m_wndListClust;
	CButton	m_wndClear;
	CButton	m_wndAdd;
	CComboBox	m_wndCmbSelParam;
	CButton	m_wndSetSp;
	CButton	m_wndRemove;
	CButton	m_wndCheck4;
	CButton	m_wndCheck3;
	CButton	m_wndCheck2;
	CButton	m_wndCheck1;
	CButton	m_wndOK;
	CButton	m_wndStop;
	CButton	m_wndPlay;
	CButton	m_wndNext;
	CComboBox	m_wndComboProp;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditSpikes)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEditSpikes)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnPaint();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnNext();
	afx_msg void OnPlay();
	afx_msg void OnStop();
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSelchangeComboprop();
	afx_msg void OnCheckCh1();
	afx_msg void OnCheckCh2();
	afx_msg void OnCheckCh3();
	afx_msg void OnCheckCh4();
	afx_msg void OnRemove();
	afx_msg void OnSetSp();
	afx_msg void OnAdd();
	afx_msg void OnSelchangeCmbSelParam();
	afx_msg void OnBclear();
	afx_msg void OnExtParam();
	afx_msg void OnItemchangedListClust(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITSPIKES_H__AD5F9CE0_9E13_11D6_9179_9DFBF872187C__INCLUDED_)
