// $Id: pca2.cpp,v 1.1 2008/05/06 02:24:04 samn Exp $ 
#include "stdafx.h"
#include <vector>
#include <fstream>
#include <algorithm>
#include "diag.hpp"
#include "pca2.hpp"
//#include "gzstream.hpp"
//#include "svd.hpp"
#include "nr\nr.h"
#include "WCMath.h"
using namespace std;

PCA::PCA(int dim) {
  dim_=dim;
  mean_=vector<PCA_T>(dim_,0.0);
  covariance_=vector< vector<PCA_T> >(dim_,vector<PCA_T>(dim_,0.0));
  counter_=0;
}

void PCA::putData(const vector<PCA_T> &in) {
  ++counter_;
  PCA_T tmp;

  for(int i=0;i<dim_;++i) {
    mean_[i]+=in[i];
  }

  for(int i=0;i<dim_;++i) {
    tmp=in[i];
    for(int j=0;j<dim_;++j) {
      covariance_[i][j]+=tmp*in[j];
    }
  }
}

void PCA::putData(A2D< PCA_T >& vData)
{
	counter_ = vData.Rows();
	mean_ = vector<PCA_T>(dim_,0.0);
	CovarMat(vData,counter_,dim_,covariance_,mean_);
}

void PCA::putData(const ::std::vector< std::vector< PCA_T > >& vData)
{
	counter_ = vData.size();
	mean_ = vector<PCA_T>(dim_,0.0);
	CovarMat<PCA_T>(vData,counter_,dim_,covariance_,mean_);
}

void PCA::save(const string &filename) const{
  /*ogzstream ofs; ofs.open(filename.c_str());
  if(!ofs.good()) {
    ERR << "[PCA::save] Cannot write PCA to '" << filename << "'."<< endl;
  } else {
    ofs << dim_ << " " <<dim_ << endl;
    ofs << "mean "  ;
    for(int i=0;i<dim_;++i) {
      ofs << mean_[i] << " "; }
    ofs << endl;

    for(int y=0;y<dim_;++y) {
      ofs << y;
      for(int x=0;x<dim_;++x) {
        ofs << " " << covariance_[y][x];
      }
      ofs << endl;
    }
    ofs << -1 << endl;
  }*/
}

void PCA::load(const string &filename) {
  /*igzstream ifs; ifs.open(filename.c_str());
  int dimy, dimx, posy;

  if(!ifs.good()) {
    ERR << "[PCA::load] Cannot open '"<<filename<<"' to read PCA." << endl;
  } else {
    ifs >> dimx >> dimy;
    if(dimx==dimy) dim_=dimx;
    else ERR << "[PCA::load] Strange: PCA not square: dimx="<< dimx << " dimy=" << dimy << endl;
    ::std::string tmpstr;
    ifs >> tmpstr;
    mean_=vector<PCA_T>(dimy);
    for(int i=0;i<dimy;++i) {
      ifs >> mean_[i];
    }
    covariance_=vector< vector<PCA_T> >(dimy,vector<PCA_T>(dimx,0.0));
    for(int y=0;y<dimy;++y) {
      ifs >> posy;
      if(posy!=y) {ERR << "[PCA::load] Strangeness in reading PCA." << endl;}
      for(int x=0;x<dimx;++x) {
        ifs >> covariance_[y][x];
      }
    }
    ifs >> posy;
    if(posy!=-1) {ERR << "[PCA::load] Reading PCA was strange. Did not end with -1." << endl;}
  }*/
}

void PCA::dataEnd() {
  for(int i=0;i<dim_;++i) {
    mean_[i]/=counter_;
  }

  for(int i=0;i<dim_;++i) {
    for(int j=0;j<dim_;++j) {
      covariance_[i][j]/=counter_;
    }
  }

  for(int i=0;i<dim_;++i) {
    for(int j=0;j<dim_;++j) {
      covariance_[i][j]-=mean_[i]*mean_[j];
    }
  }
}

void PCA::calcPCA() {

  vector<PCA_T> w(dim_);
  vector< vector<PCA_T> > v(dim_, vector<PCA_T>(dim_,0));

  //svd(covariance_,w,v);

    NR::svdcmp(covariance_, w, v);

  DBG(50) << "Eigenvalues: " ;
  for(unsigned int i=0;i<w.size();++i) {
    BLINK(50) << w[i] << " ";
  }
  BLINK(50) << endl;

  DBGI(50,{
      DBG(50) << "transform before sorting:" << endl;
      for(int i=0;i<dim_;++i) {
        for(int j=0;j<dim_;++j) {
          BLINK(50) << " " << covariance_[i][j] ;
        }
        BLINK(50) << endl;
      }
    });

  vector< pair<PCA_T, vector<PCA_T> > > toSort;
  for(unsigned int i=0;i<w.size();++i) {
    vector<PCA_T> tmp(dim_);
    for(int j=0;j<dim_;++j) tmp[j]=covariance_[j][i];
    toSort.push_back(pair<PCA_T,vector<PCA_T> >(w[i],tmp));
  }

  sort(toSort.rbegin(),toSort.rend());

  for(unsigned int i=0;i<toSort.size();++i) {
    covariance_[i]=toSort[i].second;
    w[i]=toSort[i].first;
  }
  DBG(50) << "Eigenvalues: " ;
  for(unsigned int i=0;i<w.size();++i) {
    BLINK(50) << w[i] << " ";
  }
  BLINK(50) << endl;

  DBG(50) << "transform after sorting:" << endl;
  for(int i=0;i<dim_;++i) {
    for(int j=0;j<dim_;++j) {
      BLINK(50) << " " << covariance_[i][j] ;
    }
    BLINK(50)  << endl;
  }

  eigenvalues_=w;

}

const int PCA::dim() const {
  return dim_;
}

const vector<PCA_T> & PCA::mean() const {
  return mean_;
}

const vector< vector <PCA_T> > & PCA::covariance() const {
  return covariance_;
}

const int PCA::counter() const {
  return counter_;
}

const vector<PCA_T> PCA::transform(const vector<PCA_T> &in, int dim) const {
  if(dim==0) dim=in.size();
  vector<PCA_T> result(dim,0.0);
  DBG(20) << "Transforming to dim " << dim << endl;

  for(int i=0;i<dim;++i) {
    for(unsigned int j=0;j<in.size();++j) {
      result[i]+=covariance_[i][j]*(in[j]-mean_[j]);
    }
  }
  return result;
}

void PCA::transform(PCA_T* in,int insz, PCA_T* out, int dim) const {
  if(dim==0) dim=insz;
  DBG(20) << "Transforming to dim " << dim << endl;

  for(int i=0;i<dim;++i) {
    out[i]=0.0;
    for(unsigned int j=0;j<insz;++j) {
      out[i]+=covariance_[i][j]*(in[j]-mean_[j]);
    }
  }
}




/** as PCA-matrices are rotation matrices, for this calculation it is
 *  not necessary to explicitly invert them, but instead it holds:
 *
 *   M^{-1}=transpose(M), and thus M�transpose(M)=Id
 */
const vector<PCA_T> PCA::backTransform(vector<PCA_T> in) const {
  if(int(in.size()) < dim_) { in.resize(dim_,0);} // zeropadding
  vector<PCA_T> result(dim_,0.0);
  DBG(20) << "Backtransforming" << endl;

  for(int i=0;i<dim_;++i) {
    for(int j=0;j<dim_;++j) {
      result[i]+=covariance_[j][i]*in[j];
    }
    result[i]+=mean_[i];
  }
  return result;
}
