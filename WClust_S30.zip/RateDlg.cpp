// RateDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WClust.h"
#include "RateDlg.h"


// RateDlg dialog

IMPLEMENT_DYNAMIC(RateDlg, CDialog)
RateDlg::RateDlg(CWnd* pParent /*=NULL*/)
	: CDialog(RateDlg::IDD, pParent)
{
}

RateDlg::RateDlg(CWnd* pParent,CVerxStack* pVerx,
		    CPaletteStack* pPal,CCluster* pClust)
	: CDialog(RateDlg::IDD, pParent)
{
	m_MainDataStack = pVerx;
	m_MainClusters = pClust;
	m_MainPalette = pPal;
	m_vRatings = vector<int>(m_MainClusters->GetCount());
}

RateDlg::~RateDlg()
{
}

void RateDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(RateDlg, CDialog)
END_MESSAGE_MAP()


// RateDlg message handlers
