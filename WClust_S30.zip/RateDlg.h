#pragma once

#include "MyObj.h"
#include "Vertex.h"
#include "Cluster.h"
#include "ColorComboBox.h"
#include "ChooseClDlg.h"

// RateDlg dialog

class RateDlg : public CDialog
{
	DECLARE_DYNAMIC(RateDlg)

public:
	RateDlg(CWnd* pParent = NULL);   // standard constructor
	RateDlg(CWnd* pParent,CVerxStack* pVerx,
		    CPaletteStack* pPal,CCluster* pClust);
	virtual ~RateDlg();

// Dialog Data
	enum { IDD = IDD_DLG_RATE };

	CVerxStack		*m_MainDataStack;
	CPaletteStack	*m_MainPalette;
	CCluster		*m_MainClusters;
	CChooseClDlg	*m_colDlg;
	CMiniView		*m_MyView;
	HCURSOR			m_HCross;
	CRect			m_rect, m_wndRect;
	CRect			m_DrawingRect, m_DrawingSpikesRect;
	vector<int>     m_vRatings;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
};
