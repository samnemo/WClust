#pragma once


// EClustDlg dialog

class EClustDlg : public CDialog
{
	DECLARE_DYNAMIC(EClustDlg)

public:
	EClustDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~EClustDlg();

// Dialog Data
	enum { IDD = IDD_DIALOG_ECLUST };

	int MinClust(){ return m_iMinClust; }
	int MaxClust(){ return m_iMaxClust; }
	int Iters(){ return m_iIters; }
	int ClustIters(){ return m_iClustIters; }

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	int m_iMinClust;
	int m_iMaxClust;
	int m_iIters;
	int m_iClustIters;

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
};
