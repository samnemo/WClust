// DlgPositionReg.cpp : implementation file
//

#include "stdafx.h"
#include "wclust.h"
#include "DlgPositionReg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgPositionReg dialog


CDlgPositionReg::CDlgPositionReg(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPositionReg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgPositionReg)
	m_Edit = 0.0f;
	//}}AFX_DATA_INIT
}


void CDlgPositionReg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgPositionReg)
	DDX_Text(pDX, IDC_EDIT, m_Edit);
	DDV_MinMaxFloat(pDX, m_Edit, 1.f, 1000.f);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgPositionReg, CDialog)
	//{{AFX_MSG_MAP(CDlgPositionReg)
	ON_WM_SHOWWINDOW()
	ON_BN_CLICKED(IDC_RADIO_SYNC, OnRadioSync)
	ON_BN_CLICKED(IDC_RADIO_CONST, OnRadioConst)
	ON_BN_CLICKED(IDC_RADIO_OTHER, OnRadioOther)
	ON_BN_CLICKED(IDC_RADIO_WITHOUT, OnRadioWithout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgPositionReg message handlers

BOOL CDlgPositionReg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	((CButton*) CWnd::GetDlgItem(IDC_16_7))->SetCheck(true);
	CWnd::GetDlgItem(IDC_16_7)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_20)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_33_3)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_40)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_100)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_EDIT)->EnableWindow(false);
	
	m_Edit = 20;
	CWnd::UpdateData(false);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CDlgPositionReg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CDialog::OnShowWindow(bShow, nStatus);
	
	if ( ! (m_MainDataStack->InBpfExist & 3) )
	{
		CWnd::GetDlgItem(IDC_RADIO_WITHOUT)->EnableWindow(false);
		((CButton*) CWnd::GetDlgItem(IDC_RADIO_SYNC))->SetCheck(true);
	}
	else{
		CWnd::GetDlgItem(IDC_RADIO_WITHOUT)->EnableWindow(true);
		((CButton*) CWnd::GetDlgItem(IDC_RADIO_WITHOUT))->SetCheck(true);
	}
}

void CDlgPositionReg::OnRadioSync() 
{
	CWnd::GetDlgItem(IDC_16_7)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_20)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_33_3)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_40)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_100)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_EDIT)->EnableWindow(false);
}

void CDlgPositionReg::OnRadioConst() 
{
	CWnd::GetDlgItem(IDC_16_7)->EnableWindow(true);
	CWnd::GetDlgItem(IDC_20)->EnableWindow(true);
	CWnd::GetDlgItem(IDC_33_3)->EnableWindow(true);
	CWnd::GetDlgItem(IDC_40)->EnableWindow(true);
	CWnd::GetDlgItem(IDC_100)->EnableWindow(true);
	CWnd::GetDlgItem(IDC_EDIT)->EnableWindow(false);
}

void CDlgPositionReg::OnRadioOther() 
{
	CWnd::GetDlgItem(IDC_16_7)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_20)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_33_3)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_40)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_100)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_EDIT)->EnableWindow(true);
}

void CDlgPositionReg::OnRadioWithout() 
{
	CWnd::GetDlgItem(IDC_16_7)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_20)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_33_3)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_40)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_100)->EnableWindow(false);
	CWnd::GetDlgItem(IDC_EDIT)->EnableWindow(false);
}

void CDlgPositionReg::OnOK() 
{
	char type = 0;
	float param;
	if (((CButton*) CWnd::GetDlgItem(IDC_RADIO_SYNC))->GetCheck())
	{
		type = 1;
	}
	if (((CButton*) CWnd::GetDlgItem(IDC_RADIO_CONST))->GetCheck())
	{
		type = 2;
		if (((CButton*) CWnd::GetDlgItem(IDC_16_7))->GetCheck())
			param = (float) 16;
		if (((CButton*) CWnd::GetDlgItem(IDC_20))->GetCheck())
			param = (float) 20;
		if (((CButton*) CWnd::GetDlgItem(IDC_33_3))->GetCheck())
			param = (float) 33;
		if (((CButton*) CWnd::GetDlgItem(IDC_40))->GetCheck())
			param = (float) 40;
		if (((CButton*) CWnd::GetDlgItem(IDC_100))->GetCheck())
			param = (float) 100;
	}
	if (((CButton*) CWnd::GetDlgItem(IDC_RADIO_OTHER))->GetCheck())
	{
		type = 3;
		UpdateData(true);
		param = m_Edit;
	}
	if (((CButton*) CWnd::GetDlgItem(IDC_RADIO_WITHOUT))->GetCheck())
	{
		type = 4;
	}

	
	m_MainDataStack->m_MainSyncStack.OrganizeSync(type, param);

	CDialog::OnOK();
}

