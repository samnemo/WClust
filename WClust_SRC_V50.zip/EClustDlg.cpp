// EClustDlg.cpp : implementation file
//

#include "stdafx.h"
#include "WClust.h"
#include "EClustDlg.h"
#include ".\eclustdlg.h"


// EClustDlg dialog

IMPLEMENT_DYNAMIC(EClustDlg, CDialog)
EClustDlg::EClustDlg(CWnd* pParent /*=NULL*/)
	: CDialog(EClustDlg::IDD, pParent),
	  m_iMinClust(0),
	  m_iMaxClust(0),
	  m_iIters(0),
	  m_iClustIters(0)
{
}

EClustDlg::~EClustDlg()
{
}

void EClustDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(EClustDlg, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()


// EClustDlg message handlers

void EClustDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	CEdit* edit = (CEdit*)GetDlgItem(IDC_EDIT_ECLUST);
	edit->SetFocus();
	CString strEdit;
	edit->GetWindowText(strEdit);

	sscanf(strEdit.GetString(),"%d%d%d%d",&m_iMinClust,&m_iMaxClust,&m_iIters,&m_iClustIters);
	OnOK();
}
