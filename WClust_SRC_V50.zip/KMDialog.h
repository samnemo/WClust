#pragma once


// KMDialog dialog

class KMDialog : public CDialog
{
	DECLARE_DYNAMIC(KMDialog)

public:
	KMDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~KMDialog();

	int MinClust(){ return m_iMinClusts; }
	int MaxClust(){ return m_iMaxClusts; }
	int Iters(){ return m_iIters; }
	int DBIters(){ return m_iDBIters; }
	bool Normalize(){ return (bool) m_iNormalizeData; }
	bool Medians(){ return (bool) m_iUseMedians; }

// Dialog Data
	enum { IDD = IDD_KM_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	int m_iMinClusts;
	int m_iMaxClusts;
	int m_iIters;
	int m_iDBIters;
	int m_iNormalizeData;
	int m_iUseMedians;

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
};
