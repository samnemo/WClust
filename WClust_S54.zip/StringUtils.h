#ifndef STRING_UTILS_H
#define STRING_UTILS_H

#include <string>
#include <stdio.h>

inline bool Chop(char* str)
{
	int iLen = strlen(str);
	if(iLen)
	{
		if(str[iLen-1]=='\n' || str[iLen-1]=='\r')
		{
			str[iLen-1]=0;
			Chop(str); //in case \r\n
			return true;
		}
	}
	return false;
}

#endif