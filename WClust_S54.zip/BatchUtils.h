#ifndef BATCH_UTILS
#define BATCH_UTILS

#include <string>
#include <vector>

//batch record for processing cluster quality measurement batches
struct QBatchRec
{
	std::string strBPF;        //input .bpf file path
	std::string strCL;         //input .cl file path
	int iTetrode;              //tetrode to load points from
	double dPrct;              //fraction of points to load from bpf
	std::string outCL;         //output .cl file path
	std::vector<int> vRatings; //cluster ratings
};

bool ParseQBatchLines(std::vector<std::string>& vstr, std::vector<QBatchRec>& vqb);

#endif