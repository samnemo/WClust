#ifndef FILE_UTILS_H
#define FILE_UTILS_H

#include <string>
#include <vector>

std::string GetFileExt(std::string& strPath);
CString GetFileExt(CString& strPath);
std::string GetFileName(std::string& strPath,bool bGetExt);
CString GetFileName(CString& strPath,bool bGetExt);
CString GetFilePath(CString& strPath,bool bGetExt);
CString GetDir(CString& strFilePath);
bool GetLines(FILE* fp,std::vector<std::string>& vstr);
bool GetLines(char* fname,std::vector<std::string>& vstr);

#endif