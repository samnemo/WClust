#include "stdafx.h"
#include "BatchUtils.h"
#include "FileUtils.h"

bool ParseQBatchLines(std::vector<std::string>& vstr, std::vector<QBatchRec>& vqb)
{
	int iSz = vstr.size(), i = 0;
	bool bRead = false;
	while(i<iSz)
	{
		if(i+4<iSz)
		{
			bRead = true;
			QBatchRec oB;
			oB.strBPF =   vstr[i];
			oB.strCL =    vstr[i+1];
			oB.iTetrode = atoi(vstr[i+2].c_str());
			oB.dPrct =    atof(vstr[i+3].c_str());
			oB.outCL =    vstr[i+4];
			vqb.push_back(oB);
			i+=5;
		}
		else break;
	}
	return bRead;
}

