#include "stdafx.h"
#include "Hist.h"

using namespace std;

Hist::Hist(void)
:m_dMin(0.0),
 m_dMax(0.0),
 m_iBins(0)
{
}

Hist::Hist(double dMin,double dMax,int iBins)
{
	Init(dMin,dMax,iBins);
}

Hist::~Hist(void)
{
}

bool Hist::Init(double dMin,double dMax,int iBins)
{
	if(iBins < 1 || dMin >= dMax)
	{
		return false;
	}

	m_dMin = dMin;
	m_dMax = dMax;
	m_iBins = iBins;

	m_counts = vector<int>(iBins);

	return true;
}



std::vector<double> GetClusterInfo(CVerxStack& DataStack,CCluster& MainClusters,CPaletteStack* pMainPal,CFile* pFileBPF,int iBins)
{		
	//distrib for each cluster + 1 for full distrib
	int iClusts = MainClusters.GetCount() + 1;
	std::vector< std::vector<Hist> > vDistribs(iClusts);
	int iDims = DataStack.GetDimension();
	
	int iD=0,iC=0; 
	for(iC=0;iC<iClusts;iC++)
	{
		vDistribs[iC] = std::vector<Hist>(iDims);
		for(iD=0;iD<iDims;iD++)
		{	//make sure to do +1 for dimension indices in DataStack
			vDistribs[iC][iD].Init(DataStack.GetMin(iD+1),DataStack.GetMax(iD+1),iBins);
		}
	}
	
	//go through clusters
	//each cluster checks ALL spikes for membership
	//inefficient...but is there a better way without changing the data structures?
	
	CVertex* verx;
	MY_SPIKE_STACK::iterator indexSp;

	for(indexSp=DataStack.m_SpikesStack.begin();indexSp!=DataStack.m_SpikesStack.end();indexSp++)
	{
		bool bRead = (*indexSp)->type != 1 && pFileBPF!=0 && pMainPal!=0;
		if(bRead)
		{	//read spike from disk
			verx = new CVertex(pMainPal);
			DataStack.LoadBPFElde(verx, pFileBPF, (*indexSp)->offset );
		
			if (MainClusters.GetSwap())
			{
				verx->Swap(DataStack.NUM_CHANNELS, DataStack.NUM_SAMPLES);
			}
			MainClusters.CalcParamOneSpike( &DataStack, verx, *indexSp );
			verx->CheckNoise();
			MainClusters.Clustering( verx );
		}
		else
		{	// spike is in memory
			verx = (CVertex*)*(DataStack.m_VerxStack.begin() + (*indexSp)->offset);
		}
			
		//go through clusters filling out distrib info
		for(iC=0;iC<iClusts;iC++)
		{
			//either spike is in cluster or it is the FULL distribution
			//containing all spikes!!
			if(verx->IsInCluster(iC) || iC==iClusts-1)
			{
				for(iD=0;iD<iDims;iD++)
				{
					//+1 since index 0 is # of clusters vertex is in
					vDistribs[iC][iD].IncBinVal(verx->GetValue(iD+1));
				}
			}
		}
		//free memory if allocated
		if(bRead) delete verx;				
	}

//		vector<int> vne(iC);
//	    for(int j=0;j<iClusts;j++) vne[j] = vDistribs[j][0].NumElems();

	vector<double> vcInf(iClusts);
	for(iC=0;iC<iClusts-1;iC++)
	{
		double kldiv=0.0;
		for(iD=0;iD<iDims;iD++)
		{
			//double p = FullProb(vDistribs[iC][iD]);
			kldiv += KLDiv(vDistribs[iC][iD],vDistribs[iClusts-1][iD]);
		}
		vcInf[iC]=kldiv;
	}

	return vcInf;	
}
