#pragma once
#include "Cluster.h"

#include <math.h>

//#include <vector>

//histogram class, with automatic counting/scaling
//of values to be between min & max
class Hist //: public CMyObject
{
protected:
	
	//counts of values
	std::vector<int> m_counts;
	
	//min value in histogram
	double m_dMin;
	
	//max value in histogram
	double m_dMax;
	
	//number of bins
	int m_iBins;

public:

	//return bin # for value
	inline int ValIndex(double dVal) const
	{
		//dVal's location in range as # btwn 0 - 1
		double dFctr = (dVal - m_dMin) / (m_dMax - m_dMin);
	
		//multiply by # of bins - 1 to have it 0-based index
		return dFctr * (m_iBins - 1);
	}
	
	inline double Max() const { return m_dMax; }
	inline double Min() const { return m_dMin; }
	inline double Range() const { return m_dMax - m_dMin; }
	inline int NumBins() const { return m_iBins; }

	//number of elements in "distribution"
	inline int NumElems() const
	{
		int i=0, iElems=0;		
		for(i=0;i<m_iBins;i++)
		{
			iElems += m_counts[i];
		}		
		return iElems;
	}

	//increment bin that dVal is in by 1
	inline bool IncBinVal(double dVal)
	{
		if(dVal < m_dMin || dVal > m_dMax)
		{
			return false;
		}	
		m_counts[ValIndex(dVal)] += 1;	
		return true;
	}
	
	//set bin that dVal is in to iCount
	inline bool SetBinVal(double dVal,int iCount)
	{
		if(dVal < m_dMin || dVal > m_dMax)
		{
			return false;
		}
		m_counts[ValIndex(dVal)] = iCount;
		return true;
	}
	
	//get count of bin that dVal is in 
	inline int GetBinVal(double dVal) const { return m_counts[ValIndex(dVal)]; }

	//get probability of variable being bin i
	inline double GetBinProb(double dVal) const{ return (double) GetBinVal(dVal) / (double) NumElems(); }

	//get probability of bin i
	inline double BinProb(int i) const { return m_counts[i] / (double) NumElems(); }
	
	//direct access to bin
	const int& operator[] (int i) const { return m_counts[i]; }
	
	//initialize histogram
	bool Init(double dMin,double dMax,int iBins);

	Hist(void);
	Hist(double dMin,double dMax,int iBins);
	~Hist(void);
};

//binary logarithm
inline double log2(double d)
{
	static double dl2 = log(2.0);
	return log(d) / dl2;
}

//returns -1 iff num bins not equal
//otherwise returns KL divergence of histogram/distributions
inline double KLDiv(Hist& p,Hist&	q)
{
	if(p.NumBins() != q.NumBins())
	{
		return -1.0;
	}

	double d = 0.0;

	int i = 0 , iBins = p.NumBins();

	double eps = 10e-12;

	for(i=0;i<iBins;i++)
	{
		double pp = p.BinProb(i);
		if(pp<=eps) continue;
		double qp = q.BinProb(i);
		if(qp<=eps) continue;
		d += p.BinProb(i) * ( log2(p.BinProb(i)) - log2(q.BinProb(i)) );
	}

	return d;
}

inline double FullProb(Hist& h)
{
	double p = 0.0;
	for(int i=0;i<h.NumBins();i++)
	{
		p += h.BinProb(i);
	}
	return p;
}

//get vector containing information gain for each cluster
std::vector<double> GetClusterInfo(CVerxStack& DataStack,CCluster& MainClusters,CPaletteStack* pMainPal,CFile* pFileBPF,int iBins=25);

