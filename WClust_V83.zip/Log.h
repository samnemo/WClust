// $Id: Log.h,v 1.3 2008/04/22 21:33:33 samn Exp $ 
#ifndef LOG_H
#define LOG_H

#include <vector>
#include "A2D.h"

using namespace std;

bool Write2Log(const char* cstr,...);
bool WriteVec2Log(vector<float>& v);
bool WriteVec2Log(vector<double>& v);
bool WriteMat2Log(vector<vector<float> >& m);
bool WriteMat2Log(vector<vector<double> >& m);
bool WriteMat2Log(A2D<float>& m);
bool WriteMat2Log(A2D<int>& m);

#endif
