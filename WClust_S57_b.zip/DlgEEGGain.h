#pragma once
#include "afxwin.h"


// DlgEEGGain dialog

class DlgEEGGain : public CDialog
{
	DECLARE_DYNAMIC(DlgEEGGain)

public:
	DlgEEGGain(CWnd* pParent = NULL);   // standard constructor
	virtual ~DlgEEGGain();

	CString m_cstrEEGGain;

// Dialog Data
	enum { IDD = IDD_DIALOG1 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CEdit m_EditEEGGain;
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedOk();
};
