// DlgEEGGain.cpp : implementation file
//

#include "stdafx.h"
#include "WClust.h"
#include "DlgEEGGain.h"
#include ".\dlgeeggain.h"


// DlgEEGGain dialog

IMPLEMENT_DYNAMIC(DlgEEGGain, CDialog)
DlgEEGGain::DlgEEGGain(CWnd* pParent /*=NULL*/)
	: CDialog(DlgEEGGain::IDD, pParent)
{
}

DlgEEGGain::~DlgEEGGain()
{
}

void DlgEEGGain::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_EEG_GAIN, m_EditEEGGain);
}


BEGIN_MESSAGE_MAP(DlgEEGGain, CDialog)
	ON_BN_CLICKED(IDCANCEL, OnBnClickedCancel)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()


// DlgEEGGain message handlers

void DlgEEGGain::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	OnCancel();
}

void DlgEEGGain::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	m_EditEEGGain.GetWindowText(m_cstrEEGGain);
	OnOK();
}
